//! One separate probe quota for all pools and diagnostics in a process.
use crate::tcp::governance::{deadline_after, remaining};
use std::{
    fs::{File, OpenOptions},
    io,
    sync::{Arc, Condvar, Mutex, OnceLock},
    time::{Duration, Instant},
};

#[derive(Debug, Clone)]
pub struct ProbePolicy {
    pub max_connections: usize,
    /// Separate slots from business connections. All participants must agree.
    pub shared: Option<crate::tcp::SharedNetworkPolicy>,
    pub acquire_timeout: Duration,
}

impl Default for ProbePolicy {
    fn default() -> Self {
        Self {
            max_connections: super::DAILY_PROBE_WORKERS,
            shared: None,
            acquire_timeout: Duration::from_secs(30),
        }
    }
}

#[derive(Debug, Clone, Copy, Default)]
pub struct ProbeStats {
    pub active: usize,
    pub peak: usize,
    pub waits: u64,
    pub timeouts: u64,
}

#[derive(Debug)]
struct Coordinator {
    policy: ProbePolicy,
    state: Mutex<ProbeStats>,
    validated: Mutex<bool>,
    available: Condvar,
}

static COORDINATOR: OnceLock<Arc<Coordinator>> = OnceLock::new();

/// Configure before the first probe. No sockets are opened by this function.
pub fn configure_probes(policy: ProbePolicy) -> io::Result<()> {
    validate(&policy)?;
    COORDINATOR
        .set(Arc::new(Coordinator::new(policy)))
        .map_err(|_| io::Error::new(io::ErrorKind::AlreadyExists, "探测策略已初始化"))
}

fn validate(policy: &ProbePolicy) -> io::Result<()> {
    if !(1..=1024).contains(&policy.max_connections) || policy.acquire_timeout.is_zero() {
        return Err(io::Error::new(
            io::ErrorKind::InvalidInput,
            "探测配额须为1..1024且等待时限须为正",
        ));
    }
    deadline_after(policy.acquire_timeout)?;
    if let Some(shared) = &policy.shared {
        crate::tcp::governance::validate_shared(shared)?;
    }
    Ok(())
}

fn global() -> &'static Arc<Coordinator> {
    COORDINATOR.get_or_init(|| {
        // Applications using shared business governance automatically coordinate
        // probes in its own directory. Explicit configure_probes overrides this.
        let shared = crate::tcp::network_policy().shared.as_ref().map(|shared| {
            crate::tcp::SharedNetworkPolicy {
                directory: shared.directory.join("probes"),
                max_connections: super::DAILY_PROBE_WORKERS,
            }
        });
        Arc::new(Coordinator::new(ProbePolicy {
            shared,
            ..Default::default()
        }))
    })
}

pub fn probe_stats() -> ProbeStats {
    *global().state.lock().unwrap_or_else(|e| e.into_inner())
}

pub(super) fn acquire(deadline: Option<Instant>) -> io::Result<ProbePermit> {
    let coordinator = global();
    let local = deadline_after(coordinator.policy.acquire_timeout)?;
    coordinator.acquire(deadline.map_or(local, |deadline| deadline.min(local)))
}

impl Coordinator {
    fn new(policy: ProbePolicy) -> Self {
        Self {
            policy,
            state: Mutex::new(ProbeStats::default()),
            validated: Mutex::new(false),
            available: Condvar::new(),
        }
    }

    fn acquire(self: &Arc<Self>, deadline: Instant) -> io::Result<ProbePermit> {
        // Default inherited shared policy is lazily validated, without hiding I/O failures.
        if let Some(shared) = &self.policy.shared {
            let mut validated = crate::tcp::governance::lock_until(&self.validated, deadline)?;
            if !*validated {
                crate::tcp::governance::validate_shared_until(shared, deadline)?;
                *validated = true;
            }
        }
        let mut state = self.state.lock().unwrap_or_else(|e| e.into_inner());
        let mut waited = false;
        loop {
            let wait = match remaining(deadline) {
                Ok(wait) => wait,
                Err(error) => {
                    state.timeouts += u64::from(error.kind() == io::ErrorKind::TimedOut);
                    return Err(error);
                }
            };
            if state.active < self.policy.max_connections {
                let mut file = None;
                if let Some(shared) = &self.policy.shared {
                    for index in 0..shared.max_connections {
                        let slot = OpenOptions::new()
                            .read(true)
                            .write(true)
                            .create(true)
                            .truncate(false)
                            .open(shared.directory.join(format!("permit-{index}.lock")))?;
                        match slot.try_lock() {
                            Ok(()) => {
                                file = Some(slot);
                                break;
                            }
                            Err(std::fs::TryLockError::WouldBlock) => {}
                            Err(std::fs::TryLockError::Error(error)) => return Err(error),
                        }
                    }
                }
                if self.policy.shared.is_none() || file.is_some() {
                    state.active += 1;
                    state.peak = state.peak.max(state.active);
                    return Ok(ProbePermit {
                        coordinator: self.clone(),
                        shared: file,
                    });
                }
            }
            if !waited {
                state.waits += 1;
                waited = true;
            }
            state = self
                .available
                .wait_timeout(state, wait.min(Duration::from_millis(20)))
                .unwrap_or_else(|e| e.into_inner())
                .0;
        }
    }
}

pub(super) struct ProbePermit {
    coordinator: Arc<Coordinator>,
    shared: Option<File>,
}

impl Drop for ProbePermit {
    fn drop(&mut self) {
        self.shared.take();
        let mut state = self
            .coordinator
            .state
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        state.active -= 1;
        self.coordinator.available.notify_one();
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn independent_pools_share_slots_and_waiting_inherits_cancellation() {
        let path = std::env::temp_dir().join(format!("rustdx-probe-quota-{}", std::process::id()));
        let policy = ProbePolicy {
            max_connections: 1,
            shared: Some(crate::tcp::SharedNetworkPolicy {
                directory: path.clone(),
                max_connections: 1,
            }),
            ..Default::default()
        };
        validate(&policy).unwrap();
        let first = Arc::new(Coordinator::new(policy.clone()));
        let second = Arc::new(Coordinator::new(policy));
        let permit = first
            .acquire(deadline_after(Duration::from_secs(1)).unwrap())
            .unwrap();
        assert!(
            matches!(second.acquire(deadline_after(Duration::from_millis(10)).unwrap()), Err(e) if e.kind() == io::ErrorKind::TimedOut)
        );
        let context =
            crate::operation::OperationContext::new(Duration::from_secs(1), None).unwrap();
        let guard = context.enter();
        context.cancel();
        assert!(
            matches!(second.acquire(Instant::now() + Duration::from_secs(1)), Err(e) if e.kind() == io::ErrorKind::Interrupted)
        );
        drop(guard);
        drop(permit);
        drop(
            second
                .acquire(deadline_after(Duration::from_secs(1)).unwrap())
                .unwrap(),
        );
        assert_eq!(first.state.lock().unwrap().peak, 1);
        assert_eq!(second.state.lock().unwrap().active, 0);
        std::fs::remove_dir_all(path).unwrap();
    }
}
