# 日期化涨跌幅规则

核实日期：2026-10-22。`RULE_VERSION = exchange-rules/2026-07-06`。主板规则查询覆盖2014-01-01起，创业板2009-10-30起，科创板2019-07-22起，北交所2021-11-15起；均截止核实日期。范围外返回错误，不推测旧制度或未来政策。

对应源码7cd02e7及后续优化，尚未发布新crate版本。业务使用与证券事实维护见[OPERATIONS.md](../operations/OPERATIONS.md)，接口和迁移见[DEVELOPMENT.md](../development/DEVELOPMENT.md)、[MIGRATION.md](../release/MIGRATION.md)。外部日历扩展不会自动扩大本规则核实范围。

| 板块/阶段 | 日期条件 | 幅度 |
| --- | --- | --- |
| 沪深主板普通股票 | 覆盖期内 | ±10% |
| 沪深主板ST/*ST | 2026-07-06之前 / 当日及之后 | ±5% / ±10% |
| 创业板普通股票、ST/*ST | 2020-08-24之前 | ±10%、±5% |
| 创业板（含ST） | 2020-08-24起 | ±20% |
| 科创板（含ST） | 覆盖期内 | ±20% |
| 北交所 | 覆盖期内 | ±30% |
| 注册制IPO：主板、创业板、科创板 | 上市第1–5个交易日 | 无幅度限制 |
| 北交所IPO / 精选层平移首日 | 首日 | 无幅度限制 / ±30% |
| 创业板改革前已进入且当日仍在退市整理期 | 调用方明确给出该阶段 | ±10% |

`RuleContext` 必须包含行情日期、当日ST状态及经上市公告确认的阶段。IPO使用**交易日序号**（首日为1），不能用自然日计数；是否注册制须由上市资料确认，不能只根据查询日期推断。市场休市日检查由 `CalendarProvider` 承担。

旧核准制IPO首日返回 `LegacyIpoFirstDay`，因为发行价基准及当时专门规则不能用昨收/板块比例替代。公告明确的重新上市、退市整理首日或其他无幅度限制日使用 `AnnouncedUnrestricted`。未股改S股、特别停复牌、不同最小报价单位及证券类型尚不包含在自动规则选择中。

`prices_at` / `status_at` 无幅度限制时返回 `Ok(None)`；非法价格和不支持的制度返回 `Err`。普通股票价格四舍五入到分，并处理至少一个报价单位及最低一分的边界。现有静态 `limit_up_price`、`limit_down_price`、`limit_status` 接口保留，幅度使用2026-07-06规则，历史回测应改用日期接口。

## 原始依据

- [深交所2020-08-21新闻发布会](https://www.szse.cn/aboutus/trends/conference/t20200821_580925.html)：创业板存量股票于8月24日调整至20%、IPO前5日无幅度限制。
- [深交所创业板交易规定解读](https://investor.szse.cn/institute/rules/t20200807_580310.html)：改革前ST为5%、改革后20%、旧退市整理期例外。
- [深交所改革实施一周年](https://www.szse.cn/www/aboutus/trends/news/t20210824_587951.html)：确认2020-08-24启动。
- [上交所2014投教资料](https://edu.sse.com.cn/best/article/mcontent/c/4731131.shtml)：主板10%、风险警示5%。
- [上交所2026年交易规则](https://www.sse.com.cn/lawandrules/sselawsrules2025/trade/universal/c/c_20260424_10816492.shtml)：2026-07-06生效；3.3.13普通幅度/IPO，3.3.17取整及最小报价，风险警示章节的10%规则。
- [深交所2026修订要点](https://investor.szse.cn/institute/bookshelf/poster/P020260603538459373082.pdf)：明确主板风险警示5%→10%及2026-07-06生效。
- [北交所2021交易规则](https://www.bse.cn/jygl_list/200010919.html)：2021-11-15生效、平移首日30%；3.3.11/3.3.12列明30%及IPO首日例外。
- [上证报2023-04-08](https://paper.cnstock.com/html/2023-04/08/content_1745806.htm)：主板注册制首批2023-04-10上市，前5日无幅度限制。

这些资料核实规则，不提供逐只证券的上市/ST/退市历史数据库。规则调用方仍须提供对应事实。
