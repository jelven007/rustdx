"""tdx-cli：通达信数据命令行工具与 Python 库。

CLI 入口 ``tdx-cli``；库使用时从本包直接导入核心类型::

    from tdx_cli import TdxClient, Frequency, Market

    with TdxClient() as client:
        bars = client.kline("600519", frequency=Frequency.DAY, count=100)
"""

from tdx_cli.cli import app
from tdx_cli.tdx import (
    ExFrequency,
    Frequency,
    Market,
    SecurityType,
    TdxClient,
    classify_security,
    determine_exchange,
    determine_market,
    is_etf,
)

main = app

__version__ = "0.1.7"

__all__ = [
    "ExFrequency",
    "Frequency",
    "Market",
    "SecurityType",
    "TdxClient",
    "app",
    "classify_security",
    "determine_exchange",
    "determine_market",
    "is_etf",
    "main",
]
