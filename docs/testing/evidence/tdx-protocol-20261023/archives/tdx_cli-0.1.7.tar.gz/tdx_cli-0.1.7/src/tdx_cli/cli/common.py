"""命令组共享执行体与参数别名。

各命令组模块（kline/quote/trades/f10/blocks/files/exhq）从这里导入
``run`` 执行器与 ``SymbolArg`` 等公共参数注解，保持组间无横向依赖。
"""

from __future__ import annotations

from pathlib import Path
from typing import Annotated, Any, Callable, Optional

import typer

import tdx_cli.cli as cli_root
from tdx_cli.cli.context import run_with_client
from tdx_cli.cli.output import Format, emit

SymbolArg = Annotated[str, typer.Argument(help="证券代码，如 600519")]
CountOpt = Annotated[int, typer.Option("--count", help="条数", min=1)]
MarketOpt = Annotated[
    Optional[int],
    typer.Option("--market", help="市场代码 0=SZ 1=SH（缺省自动判断）"),
]


def _emit_pipe_safe(data: Any, fmt: Format, path: Optional[Path], *, explicit: bool) -> None:
    """管道场景 table 自动降级 json；显式 ``--format`` 不降级。"""
    if (
        not explicit
        and fmt is Format.TABLE
        and path is None
        and cli_root.is_pipe()
    ):
        emit(data, Format.JSON, None)
    else:
        emit(data, fmt, path)


def run(
    handler: Callable[[Any], Any],
    *,
    fmt: Optional[Format],
    path: Optional[Path],
    host: Optional[str],
    port: Optional[int],
    config: Optional[Path],
    need_protocol: bool = False,
    need_extended: bool = False,
) -> None:
    """命令通用执行体：建连 → 取数 → 管道感知输出。

    ``emit`` 抛出的参数类错误（如 parquet 未配 -o）转为退出码 2；
    协议层代码校验失败（``ValueError``）按设计文档转为退出码 1 + stderr。
    """
    cfg = cli_root.build_config(config, host, port)
    resolved = cli_root.resolve_emit_format(fmt, cfg)

    def body(client: Any) -> Any:
        return handler(client)

    def output(data: Any) -> None:
        try:
            _emit_pipe_safe(data, resolved, path, explicit=fmt is not None)
        except ValueError as exc:
            raise typer.BadParameter(str(exc)) from exc

    def pipeline(client: Any) -> None:
        output(body(client))

    try:
        run_with_client(pipeline, cfg, need_protocol=need_protocol, need_extended=need_extended)
    except typer.BadParameter:
        raise
    except ValueError as exc:
        typer.secho(f"错误: {exc}", err=True, fg=typer.colors.RED)
        raise typer.Exit(code=1) from exc
