"""行情组命令：quote / securities / stock-count。"""

from __future__ import annotations

from typing import Annotated, List

import typer

import tdx_cli.cli as cli_root
from tdx_cli.cli.common import run as _run
from tdx_cli.tdx import Market


def _market_from_name(value: str) -> int:
    if value == "sh":
        return Market.SH
    if value == "sz":
        return Market.SZ
    raise typer.BadParameter(f"无效市场 {value}，可选: sh/sz")


def quote(
    symbols: Annotated[List[str], typer.Argument(help="证券代码，可多个")],
    fmt: cli_root.FormatOpt = None,
    output: cli_root.OutputOpt = None,
    host: cli_root.HostOpt = None,
    port: cli_root.PortOpt = None,
    config: cli_root.ConfigOpt = None,
) -> None:
    """实时五档行情（单个或批量）"""
    if len(symbols) == 1:
        _run(
            lambda c: c.quote(symbols[0]),
            fmt=fmt, path=output, host=host, port=port, config=config,
        )
    else:
        _run(
            lambda c: c.quotes(symbols),
            fmt=fmt, path=output, host=host, port=port, config=config,
        )


def securities(
    market: Annotated[str, typer.Option("--market", help="市场: sh/sz/all")] = "all",
    filtered: Annotated[bool, typer.Option("--filtered", help="只列股票/ETF，剔除指数")] = False,
    fmt: cli_root.FormatOpt = None,
    output: cli_root.OutputOpt = None,
    host: cli_root.HostOpt = None,
    port: cli_root.PortOpt = None,
    config: cli_root.ConfigOpt = None,
) -> None:
    """证券列表"""
    if filtered:
        _run(
            lambda c: c.list_filtered_stocks(),
            fmt=fmt, path=output, host=host, port=port, config=config,
        )
        return
    market_id = None if market == "all" else _market_from_name(market)
    _run(
        lambda c: c.securities(market=market_id),
        fmt=fmt, path=output, host=host, port=port, config=config,
    )


def stock_count(
    market: Annotated[str, typer.Option("--market", help="市场: sh/sz")] = "sh",
    fmt: cli_root.FormatOpt = None,
    output: cli_root.OutputOpt = None,
    host: cli_root.HostOpt = None,
    port: cli_root.PortOpt = None,
    config: cli_root.ConfigOpt = None,
) -> None:
    """证券数量"""
    market_id = _market_from_name(market)
    _run(
        lambda c: c.security_count(market_id),
        fmt=fmt, path=output, host=host, port=port, config=config,
    )
