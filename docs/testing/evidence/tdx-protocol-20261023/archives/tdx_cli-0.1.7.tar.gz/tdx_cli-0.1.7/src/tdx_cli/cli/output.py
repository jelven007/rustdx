"""统一输出层：任意数据形态 × table/json/csv/parquet × stdout/文件。"""

from __future__ import annotations

import dataclasses
import json
import sys
from enum import Enum
from pathlib import Path
from typing import Any

import pandas as pd


class Format(str, Enum):
    TABLE = "table"
    JSON = "json"
    CSV = "csv"
    PARQUET = "parquet"


_SUFFIX_FORMATS = {".json": Format.JSON, ".csv": Format.CSV, ".parquet": Format.PARQUET}


def resolve_format(fmt: Format | None, path: Path | None) -> Format:
    """显式 --format 优先，其次按 -o 后缀推断，缺省 table。"""
    if fmt is not None:
        return fmt
    if path is not None and path.suffix in _SUFFIX_FORMATS:
        return _SUFFIX_FORMATS[path.suffix]
    return Format.TABLE


def emit(data: Any, fmt: Format | None, path: Path | None) -> None:
    """把 TdxClient 返回值输出到 stdout 或文件。

    bytes 必须配 -o 原样写盘；parquet 必须配 -o。pd.Series 归一为 dict，
    dataclass 先 asdict 归一为 dict/list[dict]，DataFrame 之外的一切先转
    DataFrame 再走表格/列存。
    """
    fmt = resolve_format(fmt, path)

    if isinstance(data, pd.Series):
        data = data.to_dict()

    if isinstance(data, bytes):
        if path is None:
            raise ValueError("二进制内容必须用 -o 写入文件")
        if fmt is not Format.TABLE:
            raise ValueError("二进制内容仅支持原样写盘（-o），不支持转换格式")
        path.write_bytes(data)
        return

    if path is None and fmt is Format.PARQUET:
        raise ValueError("parquet 格式必须用 -o 指定输出文件")

    if isinstance(data, (list, tuple)) and data and dataclasses.is_dataclass(data[0]):
        data = [dataclasses.asdict(item) for item in data]
    elif dataclasses.is_dataclass(data) and not isinstance(data, type):
        data = dataclasses.asdict(data)

    if path is not None:
        _write_file(data, fmt, path)
        return
    _write_stdout(data, fmt)


def _write_file(data: Any, fmt: Format, path: Path) -> None:
    if fmt is Format.PARQUET:
        _to_frame(data).to_parquet(path, index=False)
    elif fmt is Format.CSV:
        _to_frame(data).to_csv(path, index=False)
    elif fmt is Format.JSON:
        path.write_text(_to_json(data) + "\n", encoding="utf-8")
    else:  # TABLE
        path.write_text(_to_table(data), encoding="utf-8")


def _write_stdout(data: Any, fmt: Format) -> None:
    if fmt is Format.JSON:
        sys.stdout.write(_to_json(data) + "\n")
    else:  # TABLE / CSV 无文件时：CSV 也走 stdout
        if fmt is Format.CSV:
            sys.stdout.write(_to_frame(data).to_csv(index=False))
        else:
            sys.stdout.write(_to_table(data))


def _to_json(data: Any) -> str:
    if isinstance(data, pd.DataFrame):
        if data.empty:
            return "[]"
        return data.to_json(orient="records", force_ascii=False, date_format="iso")
    return json.dumps(data, ensure_ascii=False, default=str)


def _to_table(data: Any) -> str:
    if isinstance(data, pd.DataFrame):
        return data.to_string(index=False) + "\n"
    if isinstance(data, (list, tuple)):
        if not data:
            return "(空)\n"
        return _to_frame(data).to_string(index=False) + "\n"
    if isinstance(data, dict):
        width = max(len(str(k)) for k in data) if data else 0
        return "".join(f"{str(k):<{width}}: {v}\n" for k, v in data.items())
    return f"{data}\n"


def _to_frame(data: Any) -> pd.DataFrame:
    if isinstance(data, pd.DataFrame):
        return data
    if isinstance(data, dict):
        return pd.DataFrame([data])  # {k: scalar} → 单行，避免全标量歧义
    if isinstance(data, (list, tuple)):
        return pd.DataFrame(data)
    return pd.DataFrame([{"value": data}])
