"""通达信板块文件下载、解析与实时排名。

板块文件协议依据仓库内 MIT 许可的 ``tdx-master/protocol/model_block.go``、
``model_stat.go``、``model_spblock.go``、``model_tdxbk.go`` 和
``model_call_auction.go`` 整理。板块成分通过通达信 TCP 服务器获取，实时涨跌
仍复用 :class:`tdx_cli.tdx.TdxClient`，不依赖网页接口或 Tushare 权限。
"""

from __future__ import annotations

import io
import logging
import socket
import struct
import zipfile
import zlib
from dataclasses import dataclass, replace
from datetime import datetime, timedelta
from threading import Lock
from typing import TYPE_CHECKING, Literal

import pandas as pd

if TYPE_CHECKING:
    from tdx_cli.tdx import TdxClient

logger = logging.getLogger(__name__)

SectorCategory = Literal["industry", "concept"]

_REQUEST_PREFIX = 0x0C
_RESPONSE_PREFIX = bytes.fromhex("b1cb7400")
_TYPE_CONNECT = 0x000D
_TYPE_BLOCK_META = 0x02C5
_TYPE_BLOCK_INFO = 0x06B9
_TYPE_CALL_AUCTION = 0x056A
_BLOCK_CHUNK_SIZE = 0x7530
_BLOCK_RECORD_SIZE = 2813
_BLOCK_HEADER_SIZE = 386

_CATEGORY_FILE: dict[SectorCategory, str] = {
    "industry": "block_hy.dat",
    "concept": "block_gn.dat",
}

# tdx-master/hosts.go 中适用于新版文件协议的节点。它们独立于标准行情
# 节点列表，避免不同握手实现互相影响。
TDX_BLOCK_SERVERS = [
    ("124.71.187.122", 7709),
    ("122.51.120.217", 7709),
    ("111.229.247.189", 7709),
    ("122.51.232.182", 7709),
    ("118.25.98.114", 7709),
    ("124.70.199.56", 7709),
    ("121.36.225.169", 7709),
    ("123.60.70.228", 7709),
    ("123.60.73.44", 7709),
    ("124.70.133.119", 7709),
]


@dataclass(frozen=True)
class TdxBlock:
    """一个通达信板块及其成分股代码。"""

    name: str
    block_type: int
    codes: tuple[str, ...]
    index: str = ""
    market_codes: tuple[str, ...] = ()


@dataclass(frozen=True)
class TdxIndexDefinition:
    """板块名称到 880xxx/881xxx 指数代码的配置记录。"""

    name: str
    code: str
    index_type: int = 0
    subtype: int = 0
    reference: str = ""


@dataclass(frozen=True)
class TdxBlockAlias:
    """概念板块简称与全称的桥接记录。"""

    short: str
    full: str


@dataclass(frozen=True)
class TdxIndustryAssignment:
    """单只证券的通达信与申万行业代码。"""

    market: int
    code: str
    tdx_industry: str
    sw_industry: str


@dataclass(frozen=True)
class TdxStockStat:
    """``tdxstat.cfg`` 中经过 tdx-master 实盘核验的统计字段。"""

    market: int
    code: str
    date: str
    pe_ttm: float
    trend_days: int
    change_pct: float
    pe_static: float
    dividend_yield: float
    change_5d: float
    change_10d: float
    change_20d: float
    change_60d: float
    change_ytd: float
    fields: tuple[str, ...]


@dataclass(frozen=True)
class TdxStockStat2:
    """``tdxstat2.cfg`` 中经过 tdx-master 核验的资金与板块字段。"""

    market: int
    code: str
    date: str
    block_index: str
    amount: float
    previous_amount: float
    ipo_price: float
    high_52w: float
    low_52w: float
    fields: tuple[str, ...]


@dataclass(frozen=True)
class TdxIpoSubscription:
    """``xgsg.cfg`` 中的新股申购记录。"""

    market: int
    code: str
    date: str
    issue_price: float
    name: str
    fields: tuple[str, ...]


@dataclass(frozen=True)
class TdxCallAuctionTick:
    """集合竞价时点；``side`` 为 1 买方未匹配、-1 卖方未匹配。"""

    time: str
    price: float
    matched_volume: int
    unmatched_volume: int
    side: int


@dataclass(frozen=True)
class _Response:
    """已完成解压和长度校验的标准行情响应。"""

    msg_id: int
    message_type: int
    data: bytes


def encode_request_frame(msg_id: int, message_type: int, data: bytes) -> bytes:
    """编码标准行情请求帧。作为公开函数保留，便于协议回归测试。"""
    length = len(data) + 2
    return bytes([_REQUEST_PREFIX]) + struct.pack(
        "<IBHHH", msg_id, 1, length, length, message_type
    ) + data


def parse_block_file(data: bytes) -> list[TdxBlock]:
    """解析 ``block_*.dat`` 固定记录格式。

    布局对应 ``tdx-master/protocol/model_block.go:ParseBlockFile``：偏移 384
    是板块数，每个板块为 9 字节名称、2 字节成分数、2 字节类型及 400 个
    7 字节市场代码。记录即使少于 400 个成分也保持 2813 字节定长。
    """
    if len(data) < _BLOCK_HEADER_SIZE:
        return []

    block_count = struct.unpack_from("<H", data, 384)[0]
    position = _BLOCK_HEADER_SIZE
    blocks: list[TdxBlock] = []

    for _ in range(block_count):
        if position + _BLOCK_RECORD_SIZE > len(data):
            break

        raw_name = data[position : position + 9].split(b"\0", 1)[0]
        name = raw_name.decode("gbk", errors="replace").strip()
        stock_count, block_type = struct.unpack_from("<HH", data, position + 9)
        codes_position = position + 13
        codes: list[str] = []
        market_codes: list[str] = []

        for index in range(min(stock_count, 400)):
            raw_code = data[codes_position + index * 7 : codes_position + (index + 1) * 7]
            market_code = raw_code.split(b"\0", 1)[0].decode("ascii", errors="ignore")
            # 文件内为 1/0 + 六位代码；行情接口只需要六位代码。
            code = market_code[-6:]
            if market_code[:1] in {"0", "1", "2"} and len(code) == 6 and code.isdigit():
                market_codes.append(market_code)
            if market_code[:1] in {"0", "1"} and len(code) == 6 and code.isdigit():
                codes.append(code)

        if name and codes:
            blocks.append(
                TdxBlock(
                    name=name,
                    block_type=block_type,
                    codes=tuple(codes),
                    market_codes=tuple(market_codes),
                )
            )
        position += _BLOCK_RECORD_SIZE

    return blocks


def parse_tdx_industry_blocks(tdxhy_data: bytes, incon_data: bytes) -> list[TdxBlock]:
    """由个股行业归属和行业代码表构造通达信二级行业板块。

    ``tdxhy.cfg`` 的个股可能落在三级行业（例如 ``T110201``），排名统一上卷到
    四位数字的二级行业（``T1102``），避免数百个过细小行业造成榜单噪声。
    """
    names: dict[str, str] = {}
    in_tdx_industry = False
    for raw_line in incon_data.decode("gbk", errors="replace").splitlines():
        line = raw_line.strip()
        if line == "#TDXNHY":
            in_tdx_industry = True
            continue
        if in_tdx_industry and line.startswith("#"):
            break
        if not in_tdx_industry or "|" not in line:
            continue
        code, name = line.split("|", 1)
        if code.startswith("T") and name:
            names[code] = name

    members: dict[str, list[str]] = {}
    for raw_line in tdxhy_data.decode("ascii", errors="ignore").splitlines():
        fields = raw_line.strip().split("|")
        if len(fields) < 3 or fields[0] not in {"0", "1"} or len(fields[1]) != 6:
            continue
        industry_code = fields[2]
        normalized = industry_code[:5] if len(industry_code) >= 5 else industry_code
        if normalized in names:
            members.setdefault(normalized, []).append(fields[1])

    return [
        TdxBlock(name=names[code], block_type=0, codes=tuple(dict.fromkeys(codes)))
        for code, codes in members.items()
        if codes
    ]


def parse_tdx_industry_assignments(data: bytes) -> list[TdxIndustryAssignment]:
    """解析 ``tdxhy.cfg`` 的逐股通达信/申万行业归属。"""
    result: list[TdxIndustryAssignment] = []
    for line in data.decode("ascii", errors="ignore").splitlines():
        fields = line.strip().split("|")
        if len(fields) < 3 or not fields[0].isdigit() or not fields[1]:
            continue
        result.append(
            TdxIndustryAssignment(
                market=int(fields[0]),
                code=fields[1],
                tdx_industry=fields[2],
                sw_industry=fields[5] if len(fields) >= 6 else fields[-1],
            )
        )
    return result


def parse_tdx_index_definitions(data: bytes) -> list[TdxIndexDefinition]:
    """解析 ``tdxzs.cfg`` 的板块名称和指数代码映射。

    字段顺序与 ``tdx-master/protocol/model_block.go:ParseTdxZs`` 保持一致。
    """
    result: list[TdxIndexDefinition] = []
    for line in _decode_gbk_lines(data):
        if not line or line.startswith("#"):
            continue
        fields = line.split("|")
        if len(fields) < 2 or not fields[0] or not fields[1]:
            continue
        result.append(
            TdxIndexDefinition(
                name=fields[0],
                code=fields[1],
                index_type=_to_int(_field(fields, 2)),
                subtype=_to_int(_field(fields, 3)),
                reference=_field(fields, 5),
            )
        )
    return result


def parse_tdx_block_aliases(data: bytes) -> list[TdxBlockAlias]:
    """解析 ``tdxbk.cfg`` 的板块简称到全称映射。

    ``block_gn.dat`` 使用简称而 ``tdxzs.cfg`` 使用全称，因此该映射是补全
    概念板块指数代码所必需的中间桥。
    """
    result: list[TdxBlockAlias] = []
    for line in _decode_gbk_lines(data):
        fields = line.split("|")
        if line and not line.startswith("#") and len(fields) >= 3 and fields[1] and fields[2]:
            result.append(TdxBlockAlias(short=fields[1], full=fields[2]))
    return result


def fill_block_indexes(
    blocks: list[TdxBlock],
    definitions: list[TdxIndexDefinition],
    aliases: list[TdxBlockAlias] | None = None,
) -> list[TdxBlock]:
    """通过名称及简称映射为板块补充 880xxx/881xxx 指数代码。

    先直接匹配可减少歧义，仅在未命中时才走“简称→全称→指数代码”链路。
    """
    name_to_code = {item.name: item.code for item in definitions}
    short_to_full = {item.short: item.full for item in aliases or []}
    result: list[TdxBlock] = []
    for block in blocks:
        code = name_to_code.get(block.name, "")
        if not code and block.name in short_to_full:
            code = name_to_code.get(short_to_full[block.name], "")
        result.append(replace(block, index=code))
    return result


def parse_sp_blocks(data: bytes) -> list[TdxBlock]:
    """解析不受 400 成分上限约束的 ``spblock.dat``。"""
    result: list[TdxBlock] = []
    name = ""
    codes: list[str] = []
    for line in _decode_gbk_lines(data):
        line = line.strip("\x00 ")
        if line.startswith("#"):
            if name:
                result.append(TdxBlock(name=name, block_type=0, codes=tuple(codes)))
            name, codes = line[1:].strip(), []
        elif name and len(line) == 7 and line.isdigit():
            codes.append(line)
    if name:
        result.append(TdxBlock(name=name, block_type=0, codes=tuple(codes)))
    return result


def parse_tdx_stock_stats(data: bytes) -> list[TdxStockStat]:
    """解析全市场综合统计，只命名 tdx-master 已核验的字段。"""
    result: list[TdxStockStat] = []
    for fields in _pipe_records(data, minimum_fields=5):
        result.append(
            TdxStockStat(
                market=_to_int(_field(fields, 0)),
                code=_field(fields, 1),
                date=_field(fields, 4),
                pe_ttm=_to_float_value(_field(fields, 3)),
                trend_days=_to_int(_field(fields, 5)),
                change_pct=_to_float_value(_field(fields, 6)),
                pe_static=_to_float_value(_field(fields, 9)),
                dividend_yield=_to_float_value(_field(fields, 10)),
                change_5d=_to_float_value(_field(fields, 28)),
                change_10d=_to_float_value(_field(fields, 30)),
                change_20d=_to_float_value(_field(fields, 18)),
                change_60d=_to_float_value(_field(fields, 20)),
                change_ytd=_to_float_value(_field(fields, 21)),
                fields=tuple(fields),
            )
        )
    return result


def parse_tdx_stock_stats2(data: bytes) -> list[TdxStockStat2]:
    """解析资金与板块统计，未知列完整保留在 ``fields``。"""
    result: list[TdxStockStat2] = []
    for fields in _pipe_records(data, minimum_fields=14):
        result.append(
            TdxStockStat2(
                market=_to_int(_field(fields, 0)),
                code=_field(fields, 1),
                date=_field(fields, 2),
                block_index=_field(fields, 13),
                amount=_to_float_value(_field(fields, 3)),
                previous_amount=_to_float_value(_field(fields, 5)),
                ipo_price=_to_float_value(_field(fields, 16)),
                high_52w=_to_float_value(_field(fields, 17)),
                low_52w=_to_float_value(_field(fields, 18)),
                fields=tuple(fields),
            )
        )
    return result


def parse_tdx_ipo_subscriptions(data: bytes) -> list[TdxIpoSubscription]:
    """解析 ``xgsg.cfg`` 新股申购列表。"""
    result: list[TdxIpoSubscription] = []
    for fields in _pipe_records(data, minimum_fields=15):
        result.append(
            TdxIpoSubscription(
                market=_to_int(_field(fields, 0)),
                code=_field(fields, 1),
                date=_field(fields, 2),
                issue_price=_to_float_value(_field(fields, 3)),
                name=_field(fields, 14),
                fields=tuple(fields),
            )
        )
    return result


class TdxProtocolClient:
    """通达信标准行情补充协议：文件、配置与集合竞价。"""

    def __init__(
        self,
        servers: list[tuple[str, int]] | None = None,
        connect_timeout: float = 1.5,
        request_timeout: float = 8.0,
    ):
        self.servers = servers or TDX_BLOCK_SERVERS
        self.connect_timeout = connect_timeout
        self.request_timeout = request_timeout
        self._socket: socket.socket | None = None
        self._msg_id = 0
        self._zhb_cache: dict[str, bytes] | None = None

    def __enter__(self) -> TdxProtocolClient:
        self.connect()
        return self

    def __exit__(self, *_args: object) -> None:
        self.close()

    def connect(self) -> None:
        """按配置顺序连接节点，并用协议连接帧验证服务可用。"""
        errors: list[str] = []
        for host, port in self.servers:
            sock: socket.socket | None = None
            try:
                sock = socket.create_connection((host, port), timeout=self.connect_timeout)
                sock.settimeout(self.request_timeout)
                self._socket = sock
                self._request(_TYPE_CONNECT, b"\x01")
                self._server_index = self.servers.index((host, port))
                logger.info("连接通达信板块服务器: %s:%d", host, port)
                return
            except (OSError, TimeoutError, ValueError, zlib.error) as exc:
                errors.append(f"{host}:{port}={exc}")
                if sock is not None:
                    sock.close()
                self._socket = None
        raise ConnectionError("所有通达信板块服务器均不可达: " + "; ".join(errors[-3:]))

    def _reconnect(self, index: int, errors: list[str], reason: str) -> None:
        """关闭当前连接，换 servers[index] 重新建连。"""
        host, port = self.servers[index]
        self.close()
        try:
            sock = socket.create_connection((host, port), timeout=self.connect_timeout)
            sock.settimeout(self.request_timeout)
            self._socket = sock
            self._msg_id = 0
            self._request(_TYPE_CONNECT, b"\x01")
            self._server_index = index
            logger.info("节点失效换源: %s -> %s:%d", reason, host, port)
        except (OSError, TimeoutError, ValueError, zlib.error) as exc:
            errors.append(f"{host}:{port}={exc}")
            if self._socket is not None:
                self._socket.close()
                self._socket = None
            raise ConnectionError(str(exc)) from exc

    def _rotate_until_success(self, filename: str, operation, errors: list[str]):
        """在节点间轮换执行 operation，直至成功或耗尽节点。

        换源后失败会继续向后尝试；连不上的节点记入 errors 后跳过，
        不会因“尚未连接”阻塞后续节点。
        """
        index = getattr(self, "_server_index", 0)
        last_exc: Exception | None = None
        while index < len(self.servers):
            try:
                return operation()
            except (OSError, ValueError, TimeoutError, zlib.error) as exc:
                errors.append(f"{self.servers[index][0]}:{self.servers[index][1]}={exc}")
                last_exc = exc
            # 当前节点失败，依次尝试后续节点建连；连接失败继续向后跳。
            index += 1
            while index < len(self.servers):
                try:
                    self._reconnect(index, errors, f"{filename} 下载失败")
                    break
                except ConnectionError:
                    index += 1
        raise ValueError(
            f"板块文件 {filename} 在所有节点均失败: " + "; ".join(errors[-3:])
        ) from last_exc

    def close(self) -> None:
        """关闭 TCP 连接；已下载的 zhb 内存缓存仍可复用。"""
        if self._socket is not None:
            self._socket.close()
            self._socket = None

    def get_block_file(self, filename: str) -> bytes:
        """先查询文件大小，再分块下载完整板块文件；节点失效时自动换源重试。"""
        meta_data = filename.encode("ascii")[:40].ljust(40, b"\0")
        errors: list[str] = []

        def fetch_meta_and_chunks() -> bytes:
            meta = self._request(_TYPE_BLOCK_META, meta_data).data
            if len(meta) < 4:
                raise ValueError(f"板块文件 {filename} 元信息不足")
            file_size = struct.unpack_from("<I", meta)[0]
            if file_size <= 0:
                raise ValueError(f"板块文件 {filename} 无数据")

            result = bytearray()
            while len(result) < file_size:
                size = min(_BLOCK_CHUNK_SIZE, file_size - len(result))
                chunk = self._request(
                    _TYPE_BLOCK_INFO,
                    _block_info_payload(len(result), size, filename),
                ).data
                if len(chunk) < 4:
                    break
                content = chunk[4:]
                if not content:
                    break
                result.extend(content)

            if len(result) < file_size:
                raise OSError(
                    f"板块文件 {filename} 下载不完整: {len(result)}/{file_size}"
                )
            return bytes(result[:file_size])

        return self._rotate_until_success(filename, fetch_meta_and_chunks, errors)

    def get_report_file(self, filename: str) -> bytes:
        """下载无需预查大小的通达信报表文件（例如 ``zhb.zip``）。"""
        result = bytearray()
        while True:
            response = self._request(
                _TYPE_BLOCK_INFO,
                _block_info_payload(len(result), _BLOCK_CHUNK_SIZE, filename),
            ).data
            content = response[4:] if len(response) >= 4 else b""
            if not content:
                break
            result.extend(content)
            if len(content) < _BLOCK_CHUNK_SIZE:
                break
        return bytes(result)

    def get_zhb_files(self) -> dict[str, bytes]:
        """下载并在内存中解压 ``zhb.zip``。"""
        if self._zhb_cache is not None:
            return self._zhb_cache
        raw = self.get_report_file("zhb.zip")
        if not raw:
            raise ValueError("zhb.zip 无数据")
        with zipfile.ZipFile(io.BytesIO(raw)) as archive:
            self._zhb_cache = {
                name.rsplit("/", 1)[-1]: archive.read(name) for name in archive.namelist()
            }
        return self._zhb_cache

    def get_block_data(self, filename: str) -> list[TdxBlock]:
        """下载并解析一个二进制定长板块文件。"""
        return parse_block_file(self.get_block_file(filename))

    def get_block_data_with_index(self, filename: str) -> list[TdxBlock]:
        """解析板块成分，并通过 zhb 配置补全板块指数代码。"""
        files = self.get_zhb_files()
        return fill_block_indexes(
            self.get_block_data(filename),
            parse_tdx_index_definitions(files.get("tdxzs.cfg", b"")),
            parse_tdx_block_aliases(files.get("tdxbk.cfg", b"")),
        )

    def get_sp_blocks(self) -> list[TdxBlock]:
        """获取不受 400 个成分上限限制的专业板块。"""
        return parse_sp_blocks(self._zhb_file("spblock.dat"))

    def get_tdx_industries(self) -> list[TdxIndustryAssignment]:
        """获取全市场逐股行业归属。"""
        return parse_tdx_industry_assignments(self.get_block_file("tdxhy.cfg"))

    def get_tdx_industry_blocks(self) -> list[TdxBlock]:
        """由 tdxhy.cfg 与 zhb 配置构造行业板块及其指数。

        通达信服务器已不再提供 ``block_hy.dat``，此链路是其替代方案。
        """
        tdxhy = self.get_block_file("tdxhy.cfg")
        files = self.get_zhb_files()
        return fill_block_indexes(
            parse_tdx_industry_blocks(tdxhy, files.get("incon.dat", b"")),
            parse_tdx_index_definitions(files.get("tdxzs.cfg", b"")),
            parse_tdx_block_aliases(files.get("tdxbk.cfg", b"")),
        )

    def get_tdx_index_definitions(self) -> list[TdxIndexDefinition]:
        """获取板块名称与指数代码映射。"""
        return parse_tdx_index_definitions(self._zhb_file("tdxzs.cfg"))

    def get_tdx_block_aliases(self) -> list[TdxBlockAlias]:
        """获取概念板块简称与全称映射。"""
        return parse_tdx_block_aliases(self._zhb_file("tdxbk.cfg"))

    def get_tdx_stock_stats(self) -> list[TdxStockStat]:
        """获取盘后全市场综合统计。"""
        return parse_tdx_stock_stats(self._zhb_file("tdxstat.cfg"))

    def get_tdx_stock_stats2(self) -> list[TdxStockStat2]:
        """获取盘后全市场资金与板块统计。"""
        return parse_tdx_stock_stats2(self._zhb_file("tdxstat2.cfg"))

    def get_ipo_subscriptions(self) -> list[TdxIpoSubscription]:
        """获取新股申购列表。"""
        return parse_tdx_ipo_subscriptions(self._zhb_file("xgsg.cfg"))

    def get_call_auction(self, symbol: str) -> list[TdxCallAuctionTick]:
        """获取当日集合竞价序列；``side`` 1=买方未匹配，-1=卖方未匹配。"""
        market, code = _decode_symbol(symbol)
        payload = bytes([market, 0]) + code.encode("ascii") + bytes.fromhex(
            "00000000030000000000000000000000f4010000"
        )
        return parse_call_auction(self._request(_TYPE_CALL_AUCTION, payload).data)

    def _zhb_file(self, filename: str) -> bytes:
        """从 zhb 总包读取文件，并将缺文件与空文件明确区分。"""
        data = self.get_zhb_files().get(filename)
        if data is None:
            raise KeyError(f"zhb.zip 中缺少 {filename}")
        return data

    def _request(self, message_type: int, data: bytes) -> _Response:
        """发送请求，并按消息 ID 关联响应。"""
        if self._socket is None:
            raise ConnectionError("通达信板块客户端尚未连接")
        self._msg_id += 1
        msg_id = self._msg_id
        self._socket.sendall(encode_request_frame(msg_id, message_type, data))

        while True:
            response = self._read_response()
            if response.msg_id == msg_id:
                if response.message_type != message_type:
                    raise ValueError(
                        f"通达信响应类型不匹配: {response.message_type:#x}/{message_type:#x}"
                    )
                return response

    def _read_response(self) -> _Response:
        """重新同步响应前缀，读取完整 TCP 帧并按长度标记解压。"""
        if self._socket is None:
            raise ConnectionError("通达信板块客户端尚未连接")

        window = bytearray()
        while bytes(window) != _RESPONSE_PREFIX:
            window.extend(_recv_exact(self._socket, 1))
            if len(window) > 4:
                del window[0]

        header = _recv_exact(self._socket, 12)
        msg_id = struct.unpack_from("<I", header, 1)[0]
        message_type, zip_length, raw_length = struct.unpack_from("<HHH", header, 6)
        payload = _recv_exact(self._socket, zip_length)
        data = zlib.decompress(payload) if zip_length != raw_length else payload
        if len(data) != raw_length:
            raise ValueError(f"通达信响应解压长度不匹配: {len(data)}/{raw_length}")
        return _Response(msg_id=msg_id, message_type=message_type, data=data)


# 向后兼容首版板块实现中的类名。
TdxBlockProtocolClient = TdxProtocolClient


class TdxBlockProvider:
    """带进程内缓存的板块成分提供器。"""

    def __init__(self, ttl: timedelta = timedelta(hours=12)):
        self.ttl = ttl
        self._cache: dict[SectorCategory, list[TdxBlock]] = {}
        self._loaded_at: dict[SectorCategory, datetime] = {}
        self._lock = Lock()

    def get_blocks(self, category: SectorCategory) -> list[TdxBlock]:
        """返回板块成分；刷新失败时优先保留仍可服务的过期缓存。"""
        if category not in _CATEGORY_FILE:
            raise ValueError(f"不支持的板块类别: {category}")

        now = datetime.now()
        cached = self._cache.get(category)
        if cached and now - self._loaded_at[category] < self.ttl:
            return cached

        with self._lock:
            # 下载 zhb.zip 成本较高。进入锁后必须二次检查，避免并发首访
            # 依次重复下载同一类别，而不是只依赖锁外的快速路径。
            cached = self._cache.get(category)
            if cached and now - self._loaded_at[category] < self.ttl:
                return cached
            try:
                with TdxProtocolClient() as client:
                    if category == "industry":
                        tdxhy = client.get_block_file("tdxhy.cfg")
                        files = client.get_zhb_files()
                        incon = files.get("incon.dat", b"")
                        blocks = parse_tdx_industry_blocks(tdxhy, incon)
                    else:
                        blocks = parse_block_file(client.get_block_file(_CATEGORY_FILE[category]))
                        files = client.get_zhb_files()
                    blocks = fill_block_indexes(
                        blocks,
                        parse_tdx_index_definitions(files.get("tdxzs.cfg", b"")),
                        parse_tdx_block_aliases(files.get("tdxbk.cfg", b"")),
                    )
                if not blocks:
                    raise ValueError(f"{_CATEGORY_FILE[category]} 未解析出板块")
                self._cache[category] = blocks
                self._loaded_at[category] = now
                return blocks
            except Exception:
                if cached:
                    logger.warning("刷新通达信板块失败，继续使用过期缓存", exc_info=True)
                    return cached
                raise


def fetch_tdx_sector_ranking(
    client: TdxClient,
    category: SectorCategory,
    provider: TdxBlockProvider | None = None,
    top_n: int = 10,
    bottom_n: int = 5,
) -> tuple[list[dict], list[dict]]:
    """按成分股实时行情计算头尾板块排名，且两组不会重叠。"""
    ranked = fetch_tdx_sector_snapshots(client, category, provider)
    top_count = min(max(top_n, 0), len(ranked))
    bottom_count = min(max(bottom_n, 0), max(len(ranked) - top_count, 0))
    top = ranked[:top_count]
    bottom = ranked[-bottom_count:] if bottom_count else []
    return top, bottom


def fetch_tdx_sector_snapshots(
    client: TdxClient,
    category: SectorCategory,
    provider: TdxBlockProvider | None = None,
) -> list[dict]:
    """计算一个类别的全量板块实时快照，按涨跌幅降序返回。

    板块涨跌幅采用有效成分股涨跌幅的等权平均；``coverageRate`` 单独暴露
    行情覆盖率，避免调用方把缺失报价误认为平盘。
    """
    blocks = (provider or DEFAULT_BLOCK_PROVIDER).get_blocks(category)
    all_codes = sorted({code for block in blocks for code in block.codes})
    quotes = client.batch_quotes(all_codes)

    try:
        stocks = client.list_all_stocks()
        names = dict(zip(stocks["code"].astype(str), stocks["name"].astype(str), strict=False))
    except Exception as exc:
        logger.warning("获取证券名称失败，领涨股将显示代码: %s", exc)
        names = {}

    ranked: list[dict] = []
    for block in blocks:
        members: list[tuple[str, float, float]] = []
        for code in block.codes:
            row = quotes.get(code)
            if row is None:
                continue
            price = _to_positive_float(row.get("price"))
            last_close = _to_positive_float(row.get("last_close"))
            if price is None or last_close is None:
                continue
            change_pct = (price / last_close - 1) * 100
            amount = _to_float(row.get("amount")) or 0.0
            members.append((code, change_pct, amount))

        if not members:
            continue
        leader = max(members, key=lambda item: item[1])
        ranked.append(
            {
                "sectorKey": f"{category}:{block.name}",
                "category": category,
                "name": block.name,
                "changePct": round(sum(item[1] for item in members) / len(members), 2),
                "amount": round(sum(item[2] for item in members) / 1e8, 1),
                "upCount": sum(item[1] > 0 for item in members),
                "downCount": sum(item[1] < 0 for item in members),
                "memberCount": len(block.codes),
                "quoteCount": len(members),
                "coverageRate": round(len(members) / len(block.codes) * 100, 1),
                "leadStock": names.get(leader[0], leader[0]),
            }
        )

    ranked.sort(key=lambda item: item["changePct"], reverse=True)
    return ranked


def fetch_tdx_sector_history(
    client: TdxClient,
    category: SectorCategory,
    provider: TdxBlockProvider | None = None,
    count: int = 35,
) -> list[dict]:
    """获取板块最近若干交易日历史快照，每个板块每天一条。

    历史数据使用板块指数而非逐股回放，既与 tdx-master 的指数能力一致，也
    避免为每个交易日请求数千只成分股。缺少指数映射的板块会被跳过。
    """
    blocks = (provider or DEFAULT_BLOCK_PROVIDER).get_blocks(category)
    items: list[dict] = []
    indexed_count = 0
    for block in blocks:
        if not block.index:
            continue
        try:
            bars = client.index_bars(block.index, count=count + 1, market=1)
        except Exception as exc:
            logger.warning("获取板块指数历史失败 %s(%s): %s", block.name, block.index, exc)
            continue
        valid_bars = [
            bar for bar in bars
            if _valid_bar_date(bar) and _to_positive_float(bar.get("close")) is not None
        ]
        if len(valid_bars) < 2:
            continue
        indexed_count += 1
        for previous, current in zip(valid_bars, valid_bars[1:], strict=False):
            previous_close = _to_positive_float(previous.get("close"))
            close = _to_positive_float(current.get("close"))
            if previous_close is None or close is None:
                continue
            up_count = _to_int(current.get("up_count"))
            down_count = _to_int(current.get("down_count"))
            member_count = max(up_count + down_count, len(block.codes))
            items.append(
                {
                    "sectorKey": f"{category}:{block.name}",
                    "indexCode": block.index,
                    "indexClose": round(close, 4),
                    "category": category,
                    "name": block.name,
                    "fetchTime": (
                        f"{int(current['year']):04d}-{int(current['month']):02d}-"
                        f"{int(current['day']):02d} 15:05:00"
                    ),
                    "changePct": round((close / previous_close - 1) * 100, 2),
                    "amount": round((_to_float(current.get("amount")) or 0.0) / 1e8, 1),
                    "upCount": up_count,
                    "downCount": down_count,
                    "memberCount": member_count,
                    "quoteCount": member_count,
                    "coverageRate": 100.0,
                    "leadStock": None,
                }
            )
    logger.info(
        "板块历史生成完成: category=%s, indexed=%d/%d, items=%d",
        category, indexed_count, len(blocks), len(items),
    )
    return items


def _valid_bar_date(bar: dict) -> bool:
    """验证 K 线年月日字段可构成真实日期。"""
    try:
        datetime(int(bar["year"]), int(bar["month"]), int(bar["day"]))
        return True
    except (KeyError, TypeError, ValueError):
        return False


def _block_info_payload(start: int, size: int, filename: str) -> bytes:
    """编码 tdx-master FrameInfo 对应的偏移、长度和 100 字节文件名。"""
    return struct.pack("<II", start, size) + filename.encode("ascii")[:100].ljust(100, b"\0")


def parse_call_auction(data: bytes) -> list[TdxCallAuctionTick]:
    """按 tdx-master ``model_call_auction.go`` 的 16 字节记录解析竞价序列。"""
    if len(data) < 2:
        return []
    count = struct.unpack_from("<H", data)[0]
    result: list[TdxCallAuctionTick] = []
    position = 2
    for _ in range(count):
        if position + 16 > len(data):
            break
        minute_of_day = struct.unpack_from("<H", data, position)[0]
        price = struct.unpack_from("<f", data, position + 2)[0]
        matched = struct.unpack_from("<I", data, position + 6)[0]
        unmatched = struct.unpack_from("<h", data, position + 10)[0]
        side = 1 if unmatched >= 0 else -1
        seconds = data[position + 15]
        result.append(
            TdxCallAuctionTick(
                time=f"{minute_of_day // 60:02d}:{minute_of_day % 60:02d}:{seconds:02d}",
                price=round(float(price), 3),
                matched_volume=matched,
                unmatched_volume=abs(unmatched),
                side=side,
            )
        )
        position += 16
    return result


def _decode_symbol(symbol: str) -> tuple[int, str]:
    """归一化常见沪深代码写法并推断通达信市场号。"""
    value = symbol.lower().replace(".", "")
    if value.startswith("sh") or value.endswith("sh"):
        market = 1
    elif value.startswith("sz") or value.endswith("sz"):
        market = 0
    else:
        code_guess = "".join(character for character in value if character.isdigit())[-6:]
        market = 1 if code_guess[:1] in {"5", "6", "9"} else 0
    code = "".join(character for character in value if character.isdigit())[-6:]
    if len(code) != 6:
        raise ValueError(f"无效证券代码: {symbol}")
    return market, code


def _recv_exact(sock: socket.socket, size: int) -> bytes:
    """读取恰好 ``size`` 字节，避免 TCP 分包造成半帧解析。"""
    result = bytearray()
    while len(result) < size:
        chunk = sock.recv(size - len(result))
        if not chunk:
            raise ConnectionError("通达信服务器提前关闭连接")
        result.extend(chunk)
    return bytes(result)


def _decode_gbk_lines(data: bytes) -> list[str]:
    """以容错方式解码通达信 GBK 配置文件。"""
    return [line.rstrip("\r") for line in data.decode("gbk", errors="replace").splitlines()]


def _pipe_records(data: bytes, minimum_fields: int) -> list[list[str]]:
    """读取竖线分隔记录，过滤注释、空行及缺少证券代码的行。"""
    result: list[list[str]] = []
    for line in _decode_gbk_lines(data):
        if not line or line.startswith("#"):
            continue
        fields = line.split("|")
        if len(fields) >= minimum_fields and len(fields) > 1 and fields[1]:
            result.append(fields)
    return result


def _field(fields: list[str], index: int) -> str:
    """安全读取可能随服务端版本增减的配置列。"""
    return fields[index] if index < len(fields) else ""


def _to_int(value: object) -> int:
    """按配置文件的宽松语义转换整数，非法值视为缺省 0。"""
    try:
        return int(str(value).strip())
    except (TypeError, ValueError):
        return 0


def _to_float_value(value: str) -> float:
    """按配置文件的宽松语义转换浮点数，非法值视为缺省 0。"""
    try:
        return float(value.strip())
    except (TypeError, ValueError):
        return 0.0


def _to_float(value: object) -> float | None:
    """将行情字段转换为浮点值；缺失、非法或 NaN 返回 ``None``。"""
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if pd.notna(result) else None


def _to_positive_float(value: object) -> float | None:
    """返回正浮点数；价格类字段的 0 和负数按缺失处理。"""
    result = _to_float(value)
    return result if result is not None and result > 0 else None


DEFAULT_BLOCK_PROVIDER = TdxBlockProvider()
