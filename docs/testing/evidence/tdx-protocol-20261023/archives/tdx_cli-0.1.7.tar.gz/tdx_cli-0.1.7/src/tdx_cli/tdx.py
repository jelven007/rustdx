"""
通达信数据客户端封装。

协议能力与复权算法以仓库内 ``tdx-master/client.go``、
``tdx-master/protocol`` 和 ``tdx-master/docs/gbbq_除权除息与复权算法.md`` 为
基准；标准行情、文件和扩展行情均由项目自有 Python 协议层实现。本模块只负责
统一接口、分页及 DataFrame 适配，不在业务层重复解释二进制协议。
"""

from __future__ import annotations

import logging
from bisect import bisect_left
from dataclasses import dataclass
from datetime import datetime
from decimal import ROUND_HALF_UP, Decimal
from typing import Any, Literal

import pandas as pd

from tdx_cli.tdx_blocks import (
    TdxBlock,
    TdxBlockAlias,
    TdxCallAuctionTick,
    TdxIndexDefinition,
    TdxIndustryAssignment,
    TdxIpoSubscription,
    TdxProtocolClient,
    TdxStockStat,
    TdxStockStat2,
)
from tdx_cli.tdx_exhq import (
    ExBar,
    ExHqClient,
    ExInstrument,
    ExMarket,
    ExMinuteTick,
    ExQuote,
    ExQuoteListItem,
    ExTradeTick,
)
from tdx_cli.tdx_standard import (
    DEFAULT_TDX_SERVERS,
    TdxStandardClient,
)

logger = logging.getLogger("tdx_client")

# ── 服务器配置 ───────────────────────────────────────────────

TDX_SERVERS = list(DEFAULT_TDX_SERVERS)

# ── K 线频率常量 ─────────────────────────────────────────────

class Frequency:
    """K 线频率"""
    MINUTE_1 = 8
    MINUTE_5 = 0
    MINUTE_15 = 1
    MINUTE_30 = 2
    HOUR_1 = 3
    DAY = 4
    WEEK = 5
    MONTH = 6
    YEAR = 11


class ExFrequency:
    """扩展行情 K 线类型，与 Go/通达信 ExHQ 协议保持一致。"""

    MINUTE_1 = 7
    MINUTE_5 = 0
    MINUTE_15 = 1
    MINUTE_30 = 2
    HOUR_1 = 3
    DAY = 9
    WEEK = 5
    MONTH = 6
    QUARTER = 10
    YEAR = 11

# ── 市场代码 ─────────────────────────────────────────────────

class Market:
    """市场代码"""
    SZ = 0
    SH = 1

# ── 品种分类 ─────────────────────────────────────────────────

class SecurityType:
    """品种类型"""
    STOCK = "STOCK"
    ETF = "ETF"
    INDEX = "INDEX"
    FUND = "FUND"

# ── ETF 代码前缀 ─────────────────────────────────────────────

_ETF_CODE_PREFIXES = ("15", "51", "56", "58")


# ── 代码工具函数 ─────────────────────────────────────────────


def determine_market(code: str) -> int:
    """根据股票代码判断市场"""
    pure = code.split(".")[0] if "." in code else code
    if pure[0] in ("6", "9", "5", "7"):
        return Market.SH
    return Market.SZ


def determine_exchange(code: str) -> str:
    """根据股票代码判断交易所简称"""
    return "SH" if determine_market(code) == Market.SH else "SZ"


def classify_security(code: str, market: int | None = None) -> str:
    """根据市场与代码前缀判断品种类型。"""
    prefix2 = code[:2]
    first = code[0]

    # 沪深存在同码证券，例如 SH000001 是上证指数、SZ000001 是平安银行。
    # 沪市 00 开头均为指数，不能只凭代码前缀套用深市分类规则。
    if market == Market.SH and first == "0":
        return SecurityType.INDEX

    # 159 开头为深市 ETF（深圳交易所 ETF 代码段 159xxx）
    if prefix2 == "15":
        return SecurityType.ETF
    if first in ("6", "9"):
        return SecurityType.INDEX if first == "9" else SecurityType.STOCK
    if first == "5":
        if prefix2 in ("51", "52", "53", "54", "55", "56", "57", "58", "16", "18"):
            return SecurityType.ETF
        return SecurityType.FUND
    if first == "0":
        if prefix2 == "39":
            return SecurityType.INDEX
        return SecurityType.STOCK
    if first == "3":
        return SecurityType.INDEX if prefix2 == "39" else SecurityType.STOCK
    return SecurityType.STOCK


def is_etf(code: str) -> bool:
    """判断是否为 ETF"""
    pure = code.split(".")[0] if "." in code else code
    return pure.startswith(_ETF_CODE_PREFIXES)


# ── 客户端 ───────────────────────────────────────────────────


class TdxClient:
    """通达信统一数据客户端。

    标准沪深行情在 :meth:`connect` 时建立连接；文件/板块补充协议与扩展行情
    在第一次调用对应方法时懒连接，并由同一个上下文管理器统一关闭。
    """

    def __init__(
        self,
        *,
        standard_client: Any | None = None,
        protocol_client: TdxProtocolClient | None = None,
        extended_client: ExHqClient | None = None,
    ):
        self._client = standard_client
        self._protocol_client = protocol_client
        self._extended_client = extended_client

    @property
    def connected(self) -> bool:
        """标准沪深行情连接是否可用。"""
        return self._client is not None

    @property
    def protocol_connected(self) -> bool:
        """补充文件协议是否已初始化。"""
        return self._protocol_client is not None

    @property
    def extended_connected(self) -> bool:
        """扩展行情协议是否已初始化。"""
        return self._extended_client is not None

    def connect(self) -> None:
        """连接通达信服务器（自动重试多台）"""
        if self._client is not None:
            return
        client = TdxStandardClient(servers=TDX_SERVERS)
        client.connect()
        self._client = client

    def connect_all(self, *, extended: bool = True) -> None:
        """预连接全部协议；通常直接使用懒连接即可。"""
        self.connect()
        self._protocol()
        if extended:
            self._extended()

    def close(self) -> None:
        """关闭标准、补充和扩展行情的全部连接。"""
        clients = ("_extended_client", "_protocol_client", "_client")
        for attribute in clients:
            client = getattr(self, attribute)
            if client is not None:
                try:
                    client.close()
                except Exception as exc:
                    logger.warning("关闭通达信连接失败 %s: %s", attribute, exc)
                finally:
                    setattr(self, attribute, None)

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, *args):
        self.close()

    def _standard(self) -> Any:
        """返回已连接的标准行情客户端，避免公共方法隐式创建半连接状态。"""
        if self._client is None:
            raise ConnectionError("通达信标准行情尚未连接，请先调用 connect() 或使用 with")
        return self._client

    def _protocol(self) -> TdxProtocolClient:
        """懒连接文件/配置补充协议客户端。"""
        if self._protocol_client is None:
            client = TdxProtocolClient()
            client.connect()
            self._protocol_client = client
        return self._protocol_client

    def _extended(self) -> ExHqClient:
        """懒连接扩展行情客户端。"""
        if self._extended_client is None:
            client = ExHqClient()
            client.connect()
            self._extended_client = client
        return self._extended_client

    # ── 基础列表 ──────────────────────────────────────────────

    def list_stocks(self, market: int) -> pd.DataFrame:
        """获取市场全量品种列表（code, name, pre_close, volunit, decimal_point）"""
        return self._standard().stocks(market=market)

    def security_count(self, market: int) -> int:
        """获取指定市场证券数量。"""
        return int(self._standard().client.get_security_count(market))

    def list_all_stocks(self) -> pd.DataFrame:
        """获取沪深全量品种列表"""
        sh = self.list_stocks(Market.SH)
        sz = self.list_stocks(Market.SZ)
        return pd.concat([sh, sz], ignore_index=True)

    def securities(self, market: int | None = None) -> pd.DataFrame:
        """统一证券列表入口；market 为空时返回沪深两市。"""
        return self.list_all_stocks() if market is None else self.list_stocks(market)

    def list_filtered_stocks(self) -> pd.DataFrame:
        """获取过滤后的品种列表（排除债券、统计板块），含 exchange 和 security_type"""
        sh_stocks = self.list_stocks(Market.SH).assign(exchange="SH", market=Market.SH)
        sz_stocks = self.list_stocks(Market.SZ).assign(exchange="SZ", market=Market.SZ)
        all_stocks = pd.concat([sh_stocks, sz_stocks], ignore_index=True)

        filtered = all_stocks[all_stocks["code"].apply(should_include)].copy()
        filtered["security_type"] = filtered.apply(
            lambda row: classify_security(row["code"], int(row["market"])), axis=1
        )
        filtered.drop(columns=["market"], inplace=True)
        return filtered

    # ── 实时行情 ──────────────────────────────────────────────

    def quotes(self, symbols: list[str]) -> pd.DataFrame:
        """
        获取实时行情（最多 80 只/批）

        返回字段: market, code, price, last_close, open, high, low,
                  vol, volume, amount, bid1-5, ask1-5 等
        """
        return self._standard().quotes(symbol=symbols)

    def quote(self, symbol: str) -> pd.Series | None:
        """获取单个证券五档报价，无数据时返回 ``None``。"""
        frame = self.quotes([symbol])
        return None if frame.empty else frame.iloc[0]

    def batch_quotes(self, symbols: list[str], batch_size: int = 80) -> dict[str, pd.Series]:
        """
        分批获取实时行情，合并为 {code: row} 映射
        """
        result = {}
        for i in range(0, len(symbols), batch_size):
            batch = symbols[i : i + batch_size]
            try:
                df = self.quotes(batch)
                for _, row in df.iterrows():
                    result[row["code"]] = row
            except Exception as e:
                logger.warning("获取实时行情失败 batch %d: %s", i // batch_size + 1, e)
        return result

    # ── K 线数据 ─────────────────────────────────────────────

    def bars(
        self,
        symbol: str,
        frequency: int = Frequency.DAY,
        count: int = 100,
        market: int | None = None,
    ) -> list[dict]:
        """
        获取 K 线数据（自动分页，每页 800 条）

        Args:
            symbol: 证券代码
            frequency: K 线频率（Frequency 常量）
            count: 请求数量
            market: 市场代码（None 时自动判断）
        """
        if market is None:
            market = determine_market(symbol)

        page_size = 800
        all_bars: list[dict] = []
        remaining = count

        while remaining > 0:
            batch = min(remaining, page_size)
            offset = len(all_bars)
            raw = self._standard().client.get_security_bars(
                frequency, market, symbol, offset, batch
            )
            if not raw:
                break
            all_bars.extend(raw)
            remaining -= len(raw)
            if len(raw) < batch:
                break

        return all_bars

    def kline(
        self,
        symbol: str,
        frequency: int = Frequency.DAY,
        count: int = 100,
        market: int | None = None,
        adjustment: Literal["none", "qfq", "hfq", "qfq_ratio"] = "none",
    ) -> list[dict]:
        """统一股票 K 线入口，可直接选择不复权、前复权、后复权或比例前复权。"""
        if adjustment == "none":
            return self.bars(symbol, frequency=frequency, count=count, market=market)
        return self.adjusted_bars(
            symbol,
            frequency=frequency,
            count=count,
            market=market,
            adjustment=adjustment,
        )

    def adjusted_bars(
        self,
        symbol: str,
        frequency: int = Frequency.DAY,
        count: int = 100,
        market: int | None = None,
        adjustment: Literal["qfq", "hfq", "qfq_ratio"] = "qfq",
    ) -> list[dict]:
        """获取前复权 K 线（自动分页 + xdxr 离线复权）。

        相似度/回测/画像等对价格连续性敏感的场景必须用复权数据，否则除权日会产生
        虚假巨跌污染指标与信号。此处用 ``xdxr`` 离线计算前复权，不依赖任何外部存储。

        **复权算法**：``qfq``/``hfq`` 为减法（仿射）口径，``adjusted = factor*raw
        + offset``；``qfq_ratio`` 为比例（乘法）口径，价格 = 原始价 × 累计因子，
        因子恒正、永不产生负价——减法 qfq 对累计大额现金分红的长史股票会把
        早期价格减穿零（如 600900/600309 的 2013~2016 段），此时用 ``qfq_ratio``
        重算负价段。两种口径在最后一次除权之后的近端段数学恒等；早期段
        ``qfq_ratio`` 是「相对收益」口径，绝对幅度被几何压缩。

        **频率限制**：复权算法按日粒度计算，
        仅 ``Frequency.DAY`` 精确生效。周/月 K 的 OHLC 跨越除权日时 open 与 close
        处于不同复权基准，按日粒度复权会扭曲形态，故周/月 K **降级为不复权**
        并记录警告。如需周/月复权，应取复权日 K 后自行聚合。

        Args:
            symbol: 证券代码
            frequency: K 线频率（Frequency 常量，仅 DAY 支持复权）
            count: 请求数量
            market: 市场代码（None 时自动判断）
            adjustment: 复权算法（qfq/hfq 减法仿射；qfq_ratio 比例乘法）

        Returns:
            日 K 为前复权（OHLC 已调整），周/月 K 为不复权。按日期升序，
            字段同 :meth:`bars`。
        """
        if adjustment not in {"qfq", "hfq", "qfq_ratio"}:
            raise ValueError(f"不支持的复权类型: {adjustment}")
        if market is None:
            market = determine_market(symbol)

        raw_bars = self.bars(symbol, frequency=frequency, count=count, market=market)
        if not raw_bars:
            return []

        # 周/月 K 复权需从日 K 重聚合，当前降级不复权（避免错误复权扭曲形态）
        if frequency != Frequency.DAY:
            logger.warning(
                "adjusted_bars 仅日 K 支持复权，周/月 K 返回不复权: symbol=%s, freq=%s",
                symbol, frequency,
            )
            return _sort_bars_by_date(raw_bars)

        xdxr = self._standard().xdxr(symbol=symbol, market=market)
        if xdxr is None or xdxr.empty:
            logger.info("无除权记录，返回不复权日 K: %s", symbol)
            return _sort_bars_by_date(raw_bars)

        if adjustment == "qfq":
            adjusted = _apply_qfq(raw_bars, xdxr)
        elif adjustment == "hfq":
            adjusted = _apply_hfq(raw_bars, xdxr)
        else:
            adjusted = _apply_ratio_adjustment(raw_bars, xdxr)
        return _sort_bars_by_date(adjusted)

    def adjusted_daily_bars(
        self,
        symbol: str,
        count: int = 100,
        market: int | None = None,
    ) -> list[dict]:
        """获取前复权日 K 线（``adjusted_bars`` 的日 K 便捷别名）。

        等价于 ``adjusted_bars(symbol, frequency=Frequency.DAY, count, market)。
        保留供已有调用方（如 pattern_similarity_executor）使用，新代码优先用
        ``adjusted_bars``。
        """
        return self.adjusted_bars(symbol, frequency=Frequency.DAY, count=count, market=market)

    def back_adjusted_daily_bars(
        self,
        symbol: str,
        count: int = 100,
        market: int | None = None,
    ) -> list[dict]:
        """获取后复权日 K 线。"""
        return self.adjusted_bars(
            symbol,
            frequency=Frequency.DAY,
            count=count,
            market=market,
            adjustment="hfq",
        )

    def call_auction(self, symbol: str) -> list[TdxCallAuctionTick]:
        """获取当日集合竞价序列。"""
        return self._protocol().get_call_auction(symbol)

    def one_minute_bars(self, symbol: str, target_days: int, market: int | None = None) -> list[dict]:
        """
        获取 1 分钟 K 线，按交易日数量获取（自动分页）

        Args:
            symbol: 证券代码
            target_days: 目标交易日数量
            market: 市场代码（None 时自动判断）
        """
        if market is None:
            market = determine_market(symbol)

        bars_per_page = 800
        bars_per_day = 240
        max_pages = (target_days * bars_per_day) // bars_per_page + 3

        all_bars: list[dict] = []
        collected_dates: set[str] = set()

        for page in range(max_pages):
            offset = page * bars_per_page
            raw = self._standard().client.get_security_bars(
                7, market, symbol, offset, bars_per_page
            )
            if not raw:
                break
            all_bars.extend(raw)
            for bar in raw:
                collected_dates.add(f"{bar['year']}-{bar['month']:02d}-{bar['day']:02d}")
            complete_days = sum(
                1 for d in collected_dates
                if d < datetime.now().strftime("%Y-%m-%d")
            )
            if complete_days >= target_days:
                break

        logger.info("获取1分钟K线: %s, %d条, %d个交易日", symbol, len(all_bars), len(collected_dates))
        return all_bars

    # ── 分时数据 ──────────────────────────────────────────────

    def minute(self, symbol: str, market: int | None = None) -> pd.DataFrame:
        """获取实时分时数据"""
        if market is None:
            market = determine_market(symbol)
        return self._standard().minute(symbol=symbol)

    def minutes(self, symbol: str, date: str, market: int | None = None) -> pd.DataFrame:
        """获取历史某日分时数据（date 格式 YYYYMMDD）"""
        if market is None:
            market = determine_market(symbol)
        return self._standard().minutes(symbol=symbol, date=date)

    def history_minute(
        self, symbol: str, date: str, market: int | None = None
    ) -> pd.DataFrame:
        """历史分时的明确命名别名。"""
        return self.minutes(symbol, date=date, market=market)

    # ── 逐笔成交 ──────────────────────────────────────────────

    def transaction(self, symbol: str, start: int = 0, count: int = 2000, market: int | None = None) -> pd.DataFrame:
        """获取当日实时分笔成交。"""
        if market is None:
            market = determine_market(symbol)
        return self._standard().transaction(symbol=symbol, start=start, offset=count)

    def transactions(
        self,
        symbol: str,
        start: int = 0,
        count: int = 10,
        date: str | None = None,
        market: int | None = None,
    ) -> pd.DataFrame:
        """获取分笔成交（date 为空=当日实时，非空=历史日 YYYYMMDD）。"""
        if market is None:
            market = determine_market(symbol)
        if date:
            return self._standard().transactions(
                symbol=symbol, date=date, start=start, offset=count
            )
        return self._standard().transactions(symbol=symbol, start=start, offset=count)

    def trades(
        self,
        symbol: str,
        start: int = 0,
        count: int = 2000,
        date: str | None = None,
        market: int | None = None,
    ) -> pd.DataFrame:
        """统一逐笔成交入口；date 为空取当日，否则取 YYYYMMDD 历史日。"""
        if date is None:
            return self.transaction(symbol, start=start, count=count, market=market)
        return self.transactions(
            symbol, start=start, count=count, date=date, market=market
        )

    # ── 公司信息 ──────────────────────────────────────────────

    def f10(self, symbol: str, name: str = "", market: int | None = None) -> dict:
        """获取 F10 公司信息"""
        if market is None:
            market = determine_market(symbol)
        return self._standard().F10(symbol=symbol, name=name)

    def f10_categories(self, symbol: str, market: int | None = None) -> list[dict]:
        """获取 F10 分类目录。"""
        if market is None:
            market = determine_market(symbol)
        return self._standard().client.get_company_info_category(market, symbol)

    def f10_content(
        self,
        symbol: str,
        filename: str,
        start: int,
        length: int,
        market: int | None = None,
    ) -> str:
        """按 F10 目录条目读取正文。"""
        if market is None:
            market = determine_market(symbol)
        data = self._standard().client.get_company_info_content(
            market, symbol, filename, start, length
        )
        if isinstance(data, bytes):
            return data.decode("gbk", errors="replace")
        return str(data or "")

    def xdxr(self, symbol: str, market: int | None = None) -> pd.DataFrame:
        """获取除权除息数据"""
        if market is None:
            market = determine_market(symbol)
        return self._standard().xdxr(symbol=symbol)

    def all_xdxr(self, symbols: list[str] | None = None) -> dict[str, pd.DataFrame]:
        """获取多只或全市场股票的股本变迁；全市场调用耗时较长。"""
        if symbols is None:
            stocks = self.list_filtered_stocks()
            symbols = stocks[stocks["security_type"] == SecurityType.STOCK]["code"].tolist()
        result: dict[str, pd.DataFrame] = {}
        for symbol in symbols:
            try:
                result[symbol] = self.xdxr(symbol)
            except Exception as exc:
                logger.warning("获取股本变迁失败 %s: %s", symbol, exc)
        return result

    def finance(self, symbol: str, market: int | None = None) -> pd.DataFrame:
        """获取财务数据"""
        if market is None:
            market = determine_market(symbol)
        return self._standard().finance(symbol=symbol)

    # ── 指数 ─────────────────────────────────────────────────

    def index_bars(
        self,
        symbol: str,
        frequency: int = Frequency.DAY,
        count: int = 100,
        market: int | None = None,
    ) -> list[dict]:
        """获取指数 K 线，使用指数专用协议并自动分页。"""
        code = "".join(character for character in symbol if character.isdigit())[-6:]
        if len(code) != 6:
            raise ValueError(f"无效指数代码: {symbol}")
        if market is None:
            market = Market.SH if symbol.lower().startswith("sh") or code.startswith("88") else determine_market(code)

        page_size = 800
        result: list[dict] = []
        remaining = count
        while remaining > 0:
            batch = min(remaining, page_size)
            raw = self._standard().client.get_index_bars(
                frequency, market, code, len(result), batch
            )
            if not raw:
                break
            result.extend(raw)
            remaining -= len(raw)
            if len(raw) < batch:
                break
        return result

    def block(
        self, filename: str = "block_gn.dat", with_index: bool = True
    ) -> list[TdxBlock]:
        """获取地域/概念/指数板块成分。"""
        if with_index:
            return self._protocol().get_block_data_with_index(filename)
        return self._protocol().get_block_data(filename)

    def blocks(
        self,
        category: Literal["concept", "style", "index", "industry"] = "concept",
        *,
        with_index: bool = True,
    ) -> list[TdxBlock]:
        """按类别获取板块成分。

        ``style`` 对应通达信风格板块，其中包含地域板块。
        ``industry`` 走 ``tdxhy.cfg`` 派生链路：服务器已停止下发
        ``block_hy.dat``，逐股行业归属上卷到二级行业后构造板块。
        """
        if category == "industry":
            return self._protocol().get_tdx_industry_blocks()
        files = {
            "concept": "block_gn.dat",
            "style": "block_fg.dat",
            "index": "block_zs.dat",
        }
        try:
            filename = files[category]
        except KeyError as exc:
            raise ValueError(f"不支持的板块类别: {category}") from exc
        return self.block(filename, with_index=with_index)

    def special_blocks(self) -> list[TdxBlock]:
        """获取中证2000等不受 400 成分限制的大型指数/专业板块。"""
        return self._protocol().get_sp_blocks()

    def industry_assignments(self) -> list[TdxIndustryAssignment]:
        """获取全市场通达信/申万行业归属。"""
        return self._protocol().get_tdx_industries()

    def report_file(self, filename: str) -> bytes:
        """下载通达信报表/配置文件。"""
        return self._protocol().get_report_file(filename)

    def zhb_files(self) -> dict[str, bytes]:
        """下载并解压通达信板块配置总包。"""
        return self._protocol().get_zhb_files()

    def tdx_index_definitions(self) -> list[TdxIndexDefinition]:
        """获取板块指数名称、代码和类型映射。"""
        return self._protocol().get_tdx_index_definitions()

    def tdx_block_aliases(self) -> list[TdxBlockAlias]:
        """获取板块简称与全称映射。"""
        return self._protocol().get_tdx_block_aliases()

    def stock_stats(self) -> list[TdxStockStat]:
        """获取个股估值、涨跌幅等统计字段。"""
        return self._protocol().get_tdx_stock_stats()

    def stock_stats2(self) -> list[TdxStockStat2]:
        """获取个股成交额、板块指数等扩展统计字段。"""
        return self._protocol().get_tdx_stock_stats2()

    def ipo_subscriptions(self) -> list[TdxIpoSubscription]:
        """获取新股申购列表。"""
        return self._protocol().get_ipo_subscriptions()

    # ── 扩展行情（期货/港股/外盘）────────────────────────────

    def ex_markets(self) -> list[ExMarket]:
        """获取扩展行情市场代码表。"""
        return self._extended().markets()

    def ex_count(self) -> int:
        """获取扩展行情合约总数。"""
        return self._extended().count()

    def ex_instruments(self, start: int = 0, count: int = 100) -> list[ExInstrument]:
        """分页获取扩展行情合约列表。"""
        return self._extended().instruments(start=start, count=count)

    def ex_quote(self, market: int, code: str) -> ExQuote:
        """获取单个扩展品种五档行情。"""
        return self._extended().quote(market, code)

    def ex_quote_list(
        self, market: int, category: int, start: int = 0, count: int = 100
    ) -> list[ExQuoteListItem]:
        """获取扩展行情列表；category 2=港股、3=期货。"""
        return self._extended().quote_list(market, category, start=start, count=count)

    def ex_bars(
        self,
        category: int,
        market: int,
        code: str,
        start: int = 0,
        count: int = 100,
    ) -> list[ExBar]:
        """获取扩展品种 K 线；category 使用 :class:`ExFrequency` 常量。"""
        return self._extended().bars(category, market, code, start=start, count=count)

    def ex_minute(
        self, market: int, code: str, date: int | None = None
    ) -> list[ExMinuteTick]:
        """获取扩展品种实时或历史分时；date 为 YYYYMMDD 整数。"""
        return self._extended().minute(market, code, date=date)

    def ex_trades(
        self,
        market: int,
        code: str,
        start: int = 0,
        count: int = 100,
        date: int | None = None,
    ) -> list[ExTradeTick]:
        """获取扩展品种实时或历史逐笔成交。"""
        return self._extended().trades(market, code, start=start, count=count, date=date)

    def ex_bars_range(
        self, market: int, code: str, date: int, end_date: int
    ) -> list[ExBar]:
        """按 YYYYMMDD 日期区间获取扩展品种历史 K 线。"""
        return self._extended().bars_range(market, code, date, end_date)

    # ── 市场拥挤度 ────────────────────────────────────────────

    @dataclass
    class MarketCongestion:
        """市场拥挤度指标"""
        timestamp: str
        stock_count: int
        up_count: int
        down_count: int
        flat_count: int
        limit_up_count: int
        limit_down_count: int
        avg_change_pct: float
        median_change_pct: float
        total_amount: float
        total_volume: float
        avg_stock_amount: float
        distribution: dict[str, int]

        def to_dict(self) -> dict:
            return {
                "timestamp": self.timestamp,
                "stockCount": self.stock_count,
                "upCount": self.up_count,
                "downCount": self.down_count,
                "flatCount": self.flat_count,
                "limitUpCount": self.limit_up_count,
                "limitDownCount": self.limit_down_count,
                "avgChangePct": round(self.avg_change_pct, 2),
                "medianChangePct": round(self.median_change_pct, 2),
                "totalAmount": round(self.total_amount, 2),
                "totalVolume": round(self.total_volume, 2),
                "avgStockAmount": round(self.avg_stock_amount, 2),
                "distribution": self.distribution,
            }

    def market_congestion(self, security_type: str | None = None) -> MarketCongestion:
        """
        计算市场拥挤度指标

        通过批量获取实时行情，统计涨跌分布、涨停跌停、成交额等。

        Args:
            security_type: 品种过滤（None=全部, STOCK=仅A股）
        """
        stocks = self.list_filtered_stocks()
        if security_type:
            stocks = stocks[stocks["security_type"] == security_type]

        quotes_map = self.batch_quotes(stocks["code"].tolist())

        df = stocks.copy()
        df["price"] = df["code"].map(lambda c: float(quotes_map[c]["price"]) if c in quotes_map and quotes_map[c].get("price") else None)
        df["pre_close"] = df["code"].map(lambda c: float(quotes_map[c]["last_close"]) if c in quotes_map and quotes_map[c].get("last_close") else None)
        df["volume"] = df["code"].map(lambda c: float(quotes_map[c]["volume"]) if c in quotes_map and quotes_map[c].get("volume") else None)
        df["amount"] = df["code"].map(lambda c: float(quotes_map[c]["amount"]) if c in quotes_map and quotes_map[c].get("amount") else None)

        valid = df.dropna(subset=["price", "pre_close"]).copy()
        valid["change_pct"] = (valid["price"] / valid["pre_close"] - 1) * 100

        # 涨停判断（普通 10%，科创板/创业板 20%）
        is_st = pd.Series(False, index=valid.index)
        is_zt = pd.Series(False, index=valid.index)
        normal = ~valid["code"].str.startswith(("688", "300", "301"))
        kcb = valid["code"].str.startswith("688")
        cyb = valid["code"].str.startswith(("300", "301"))
        is_st = is_st | (normal & (valid["change_pct"] >= 9.9)) | (kcb & (valid["change_pct"] >= 19.9)) | (cyb & (valid["change_pct"] >= 19.9))
        is_zt = is_zt | (normal & (valid["change_pct"] <= -9.9)) | (kcb & (valid["change_pct"] <= -19.9)) | (cyb & (valid["change_pct"] <= -19.9))

        # 涨跌幅分布
        bins = [-20, -10, -7, -5, -3, 0, 3, 5, 7, 10, 20]
        labels = ["跌停", "-10~-7", "-7~-5", "-5~-3", "-3~0", "0~3", "3~5", "5~7", "7~10", "涨停"]
        dist = pd.cut(valid["change_pct"], bins=bins, labels=labels).value_counts().sort_index().to_dict()
        dist = {k: int(v) for k, v in dist.items()}

        return TdxClient.MarketCongestion(
            timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            stock_count=len(valid),
            up_count=int((valid["change_pct"] > 0).sum()),
            down_count=int((valid["change_pct"] < 0).sum()),
            flat_count=int((valid["change_pct"] == 0).sum()),
            limit_up_count=int(is_st.sum()),
            limit_down_count=int(is_zt.sum()),
            avg_change_pct=float(valid["change_pct"].mean()),
            median_change_pct=float(valid["change_pct"].median()),
            total_amount=float(valid["amount"].sum()),
            total_volume=float(valid["volume"].sum()),
            avg_stock_amount=float(valid["amount"].mean()) if len(valid) > 0 else 0.0,
            distribution=dist,
        )

    # ── 转换工具 ──────────────────────────────────────────────

    @staticmethod
    def convert_1min_bars(raw_bars: list[dict]) -> pd.DataFrame:
        """将 1 分钟 K 线原始数据转为 DataFrame（过滤不完整交易日）"""
        if not raw_bars:
            return pd.DataFrame()

        df = pd.DataFrame(raw_bars)
        df["时间"] = pd.to_datetime(df["datetime"])
        df = df.rename(columns={
            "open": "开盘", "close": "收盘", "high": "最高",
            "low": "最低", "vol": "成交量", "amount": "成交额",
        })
        df = df[df["收盘"] > 0]
        df = df.sort_values("时间").reset_index(drop=True)
        return TdxClient._filter_incomplete_days(df)

    @staticmethod
    def _filter_incomplete_days(df: pd.DataFrame) -> pd.DataFrame:
        """剔除未走到收盘集合竞价时段的分钟数据，防止半日样本进入回测。"""
        if df.empty:
            return df
        dates = df["时间"].dt.date.unique()
        complete = []
        for date in dates:
            latest_time = df[df["时间"].dt.date == date]["时间"].dt.time.max()
            if latest_time >= pd.Timestamp("14:57:00").time():
                complete.append(date)
            else:
                logger.info("跳过不完整交易日: %s (最新K线 %s)", date, latest_time)
        return df[df["时间"].dt.date.isin(complete)]


def _bar_date(bar: dict) -> str:
    """格式化单条 K 线为 YYYY-MM-DD 字符串，用于排序。"""
    return f"{bar['year']:04d}-{bar['month']:02d}-{bar['day']:02d}"


def _sort_bars_by_date(bars: list[dict]) -> list[dict]:
    """按日期升序排序 K 线列表。

    :meth:`TdxClient.bars` 多页拼接时，每页内部升序但页间是「最新段→更老段」
    交替，需整体排序。单页场景下为恒等操作。
    """
    return sorted(bars, key=_bar_date)


# ── 前复权计算 ───────────────────────────────────────────────

def _apply_qfq(raw_bars: list[dict], xdxr: pd.DataFrame) -> list[dict]:
    """用仿射因子计算前复权日 K，锚定最新一根 K 线。"""
    return _apply_affine_adjustment(raw_bars, xdxr, forward=True)


def _apply_hfq(raw_bars: list[dict], xdxr: pd.DataFrame) -> list[dict]:
    """用仿射因子计算后复权日 K，锚定最早一根 K 线。"""
    return _apply_affine_adjustment(raw_bars, xdxr, forward=False)


def _apply_affine_adjustment(
    raw_bars: list[dict], xdxr: pd.DataFrame, *, forward: bool
) -> list[dict]:
    """应用与 tdx-master 一致的仿射复权，并排除尚未生效的未来事件。

    公式来源为 ``tdx-master/docs/gbbq_除权除息与复权算法.md``。价格变换
    统一表示为 ``adjusted = factor * raw + offset``，从而同时覆盖送转、分红
    和配股；前复权锚定最新价格，后复权再相对首根 K 线归一化。
    """
    rights = xdxr[xdxr["category"] == 1].copy()
    if rights.empty or not raw_bars:
        return _sort_bars_by_date(raw_bars)

    rights["date"] = pd.to_datetime(rights[["year", "month", "day"]])
    events: list[tuple[pd.Timestamp, float, float]] = []
    latest = pd.Timestamp(_bar_date(max(raw_bars, key=_bar_date)))
    for _, row in rights.sort_values("date", ascending=False).iterrows():
        event_date = pd.Timestamp(row["date"])
        if event_date > latest:
            continue
        fenhong = float(row.get("fenhong") or 0)
        songzhuangu = float(row.get("songzhuangu") or 0)
        peigu = float(row.get("peigu") or 0)
        peigujia = float(row.get("peigujia") or 0)
        multiplier = (10.0 + songzhuangu + peigu) / 10.0
        cash = (fenhong - peigu * peigujia) / 10.0
        events.append((event_date, multiplier or 1.0, cash))

    bars = _sort_bars_by_date(raw_bars)
    qfq_factors: list[tuple[float, float]] = []
    for bar in bars:
        bar_date = pd.Timestamp(_bar_date(bar))
        factor, offset = 1.0, 0.0
        for event_date, multiplier, cash in events:
            if event_date > bar_date:
                factor /= multiplier
                offset -= factor * cash
        qfq_factors.append((factor, offset))

    first_factor, first_offset = qfq_factors[0]
    if first_factor == 0:
        return bars

    result: list[dict] = []
    for bar, (factor, offset) in zip(bars, qfq_factors, strict=True):
        if forward:
            adjusted_factor, adjusted_offset = factor, offset
        else:
            adjusted_factor = factor / first_factor
            adjusted_offset = (offset - first_offset) / first_factor
        item = dict(bar)
        for column in ("open", "high", "low", "close"):
            adjusted = adjusted_factor * float(bar[column]) + adjusted_offset
            item[column] = float(
                Decimal(str(adjusted)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
            )
        result.append(item)
    return result


def _apply_ratio_adjustment(raw_bars: list[dict], xdxr: pd.DataFrame) -> list[dict]:
    """比例（乘法）前复权，锚定最新一根 K 线。

    每个除权事件的因子 ``r = (P_prev - cash) / (P_prev * multiplier)``，其中
    ``P_prev`` 是事件日前一交易日bar的原始收盘价（从 ``raw_bars`` 帧内取）；
    bar 价格 = 原始价 × 其后所有事件因子的连乘积。因子恒正，
    **永不产生负价**——这是对减法 qfq（`_apply_affine_adjustment`）在累计
    大额现金分红长史上减穿零的根治方案（BaoStock/DolphinDB 同口径）。

    与减法 qfq 的关系：事件锚点 bar（收盘恰为 ``P_prev``）上两法恒等
    （``P_prev * r == (P_prev - cash) / multiplier``），最后一次除权之后的
    近端段完全一致；更早段是「相对收益」口径（几何压缩），绝对幅度低于
    减法 qfq。事件日前一交易日bar不在帧内（事件早于窗口首日，不影响帧内
    任何 bar）或因子非正（分红超过股价的坏数据）的事件跳过并记警告。
    """
    rights = xdxr[xdxr["category"] == 1].copy()
    if rights.empty or not raw_bars:
        return _sort_bars_by_date(raw_bars)

    rights["date"] = pd.to_datetime(rights[["year", "month", "day"]])
    latest = pd.Timestamp(_bar_date(max(raw_bars, key=_bar_date)))
    bars = _sort_bars_by_date(raw_bars)
    bar_dates = [_bar_date(bar) for bar in bars]

    # 事件日（含当日）起价格已是除权后基准；此前一交易日的原始收盘为 P_prev。
    # 事件在帧首（含更早）时帧内无 P_prev，且不影响帧内任何 bar，直接跳过。
    event_factors: list[tuple[str, float]] = []
    for _, row in rights.sort_values("date", ascending=False).iterrows():
        event_date = pd.Timestamp(row["date"])
        if event_date > latest:
            continue
        fenhong = float(row.get("fenhong") or 0)
        songzhuangu = float(row.get("songzhuangu") or 0)
        peigu = float(row.get("peigu") or 0)
        peigujia = float(row.get("peigujia") or 0)
        multiplier = (10.0 + songzhuangu + peigu) / 10.0 or 1.0
        cash = (fenhong - peigu * peigujia) / 10.0
        event_str = event_date.strftime("%Y-%m-%d")
        prev_index = bisect_left(bar_dates, event_str) - 1
        if prev_index < 0:
            continue
        prev_close = float(bars[prev_index]["close"])
        if prev_close <= 0:
            logger.warning("比例复权跳过 P_prev<=0 的事件: %s", event_str)
            continue
        factor = (prev_close - cash) / (prev_close * multiplier)
        if factor <= 0:
            logger.warning("比例复权跳过因子非正的事件（分红超过股价？）: %s", event_str)
            continue
        event_factors.append((event_str, factor))
    if not event_factors:
        return bars

    event_factors.sort(key=lambda item: item[0])
    event_dates = [item[0] for item in event_factors]
    # 后缀连乘：suffix[i] = ∏ r_j (j>=i)，即指针 i 之后所有事件的累计因子
    suffix = [1.0] * (len(event_factors) + 1)
    for i in range(len(event_factors) - 1, -1, -1):
        suffix[i] = event_factors[i][1] * suffix[i + 1]

    result: list[dict] = []
    pointer = 0
    for bar, bar_date in zip(bars, bar_dates, strict=True):
        while pointer < len(event_dates) and event_dates[pointer] <= bar_date:
            pointer += 1
        factor = suffix[pointer]
        item = dict(bar)
        for column in ("open", "high", "low", "close"):
            adjusted = float(bar[column]) * factor
            item[column] = float(
                Decimal(str(adjusted)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
            )
        result.append(item)
    return result


# ── 品种过滤 ─────────────────────────────────────────────────

_EXCLUDED_FIRST_DIGITS = {"1", "2", "7", "8"}
_ALLOWED_0_PREFIXES = {"00", "39"}
_ALLOWED_3_PREFIXES = {"30", "39"}


def should_include(code: str) -> bool:
    """判断是否应纳入股票池（排除债券、申购、统计板块）"""
    # 159 开头为深市 ETF，放行（排在 _EXCLUDED_FIRST_DIGITS 之前避免被 '1' 误杀）
    if code[:3] == "159":
        return True
    first = code[0]
    if first in _EXCLUDED_FIRST_DIGITS:
        return False
    if first == "0":
        return code[:2] in _ALLOWED_0_PREFIXES
    if first == "3":
        return code[:2] in _ALLOWED_3_PREFIXES
    return True


# ── 快捷函数 ─────────────────────────────────────────────────

def create_tdx_client() -> TdxClient:
    """创建并连接 TdxClient"""
    client = TdxClient()
    client.connect()
    return client
