"""F10/财务组命令。"""

from __future__ import annotations

from typing import Annotated, List, Optional

import typer

import tdx_cli.cli as cli_root
from tdx_cli.cli.common import MarketOpt, SymbolArg, run as _run


def f10(
    symbol: SymbolArg,
    name: Annotated[str, typer.Option("--name", help="F10 栏目名（缺省返回全部类别）")] = "",
    market: MarketOpt = None,
    fmt: cli_root.FormatOpt = None,
    output: cli_root.OutputOpt = None,
    host: cli_root.HostOpt = None,
    port: cli_root.PortOpt = None,
    config: cli_root.ConfigOpt = None,
) -> None:
    """F10 公司资料（--name 指定栏目）"""
    _run(
        lambda c: c.f10(symbol=symbol, name=name, market=market),
        fmt=fmt, path=output, host=host, port=port, config=config,
    )


def f10_categories(
    symbol: SymbolArg,
    market: MarketOpt = None,
    fmt: cli_root.FormatOpt = None,
    output: cli_root.OutputOpt = None,
    host: cli_root.HostOpt = None,
    port: cli_root.PortOpt = None,
    config: cli_root.ConfigOpt = None,
) -> None:
    """F10 栏目目录（filename/start/length 供 f10-content 用）"""
    _run(
        lambda c: c.f10_categories(symbol=symbol, market=market),
        fmt=fmt, path=output, host=host, port=port, config=config,
    )


def f10_content(
    symbol: SymbolArg,
    filename: Annotated[str, typer.Option(help="栏目文件名（来自 f10-categories）")],
    start: Annotated[int, typer.Option(help="起始偏移")],
    length: Annotated[int, typer.Option(help="读取长度")],
    market: MarketOpt = None,
    fmt: cli_root.FormatOpt = None,
    output: cli_root.OutputOpt = None,
    host: cli_root.HostOpt = None,
    port: cli_root.PortOpt = None,
    config: cli_root.ConfigOpt = None,
) -> None:
    """F10 栏目正文"""
    _run(
        lambda c: c.f10_content(symbol=symbol, filename=filename, start=start, length=length, market=market),
        fmt=fmt, path=output, host=host, port=port, config=config,
    )


def finance(
    symbol: SymbolArg,
    market: MarketOpt = None,
    fmt: cli_root.FormatOpt = None,
    output: cli_root.OutputOpt = None,
    host: cli_root.HostOpt = None,
    port: cli_root.PortOpt = None,
    config: cli_root.ConfigOpt = None,
) -> None:
    """财务数据"""
    _run(
        lambda c: c.finance(symbol=symbol, market=market),
        fmt=fmt, path=output, host=host, port=port, config=config,
    )


def xdxr(
    symbol: SymbolArg,
    market: MarketOpt = None,
    fmt: cli_root.FormatOpt = None,
    output: cli_root.OutputOpt = None,
    host: cli_root.HostOpt = None,
    port: cli_root.PortOpt = None,
    config: cli_root.ConfigOpt = None,
) -> None:
    """除权除息记录"""
    _run(
        lambda c: c.xdxr(symbol=symbol, market=market),
        fmt=fmt, path=output, host=host, port=port, config=config,
    )


def xdxr_all(
    symbols: Annotated[Optional[List[str]], typer.Argument(help="证券代码，缺省全市场")] = None,
    fmt: cli_root.FormatOpt = None,
    output: cli_root.OutputOpt = None,
    host: cli_root.HostOpt = None,
    port: cli_root.PortOpt = None,
    config: cli_root.ConfigOpt = None,
) -> None:
    """全市场或多标的除权除息（全市场耗时较长）"""
    _run(
        lambda c: c.all_xdxr(symbols=symbols),
        fmt=fmt, path=output, host=host, port=port, config=config,
    )
