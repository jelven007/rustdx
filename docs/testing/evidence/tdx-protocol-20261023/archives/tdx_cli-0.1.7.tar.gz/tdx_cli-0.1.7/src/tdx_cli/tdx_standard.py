"""稳健的通达信沪深标准行情客户端。

底层帧编解码由项目自有 :mod:`tdx_standard_protocol` 实现。连接管理以仓库内
``tdx-master/dial.go``、``client.go`` 和 ``hosts.go`` 为基准：多节点故障
切换、严格超时和请求失败重连。
"""

from __future__ import annotations

import logging
import re
from collections.abc import Callable, Sequence
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from time import perf_counter
from typing import Any

import pandas as pd

from tdx_cli.tdx_node_cache import NodeRankingCache
from tdx_cli.tdx_standard_protocol import NativeTdxHqApi

logger = logging.getLogger("tdx_standard")

DEFAULT_TDX_SERVERS: tuple[tuple[str, int], ...] = (
    ("60.191.117.167", 7709),
    ("117.34.114.18", 7709),
    ("183.60.224.177", 7709),
    ("58.63.254.217", 7709),
    ("117.34.114.20", 7709),
    ("202.108.253.139", 80),
)

_CODE_RE = re.compile(r"^(?:(?:sh|sz|SH|SZ))?(\d{6})$")
_DATE_RE = re.compile(r"^\d{8}$")
_SH_PREFIXES = ("5", "6", "7", "9")
_PREFERRED_SERVER_COUNT = 3
_MAX_PROBE_WORKERS = 16


@dataclass(frozen=True)
class _ServerProbe:
    server: tuple[str, int]
    latency: float
    api: Any | None = None
    error: Exception | None = None


def normalize_code(symbol: str) -> str:
    """校验证券代码并去掉可选的沪深前缀。"""
    match = _CODE_RE.fullmatch(str(symbol).strip())
    if match is None:
        raise ValueError(f"无效证券代码: {symbol}")
    return match.group(1)


def market_of(symbol: str) -> int:
    """返回通达信市场编号：0 深市，1 沪市。"""
    value = str(symbol).strip()
    if value.lower().startswith("sh"):
        return 1
    if value.lower().startswith("sz"):
        return 0
    return 1 if normalize_code(value).startswith(_SH_PREFIXES) else 0


def _to_frame(value: Any) -> pd.DataFrame:
    """将原生协议返回值转换为历史 ``TdxClient`` 契约的 DataFrame。"""
    if isinstance(value, pd.DataFrame):
        frame = value.copy()
    elif isinstance(value, list):
        frame = pd.DataFrame(value)
    elif isinstance(value, dict):
        frame = pd.DataFrame([value])
    else:
        frame = pd.DataFrame()
    if "datetime" in frame.columns:
        frame.index = pd.to_datetime(frame["datetime"])
    elif "date" in frame.columns:
        frame.index = pd.to_datetime(frame["date"])
    if "vol" in frame.columns and "volume" not in frame.columns:
        frame["volume"] = frame["vol"]
    return frame


class TdxStandardClient:
    """标准沪深行情协议客户端。"""

    def __init__(
        self,
        servers: Sequence[tuple[str, int]] | None = None,
        *,
        connect_timeout: float = 1.5,
        request_timeout: float = 8.0,
        api_factory: Callable[..., Any] = NativeTdxHqApi,
    ):
        self.servers = tuple(servers or DEFAULT_TDX_SERVERS)
        if not self.servers:
            raise ValueError("通达信服务器列表不能为空")
        if connect_timeout <= 0 or request_timeout <= 0:
            raise ValueError("连接和请求超时必须大于 0")
        self.connect_timeout = float(connect_timeout)
        self.request_timeout = float(request_timeout)
        self._candidate_servers = self.servers
        self._ranking_cache = NodeRankingCache(
            self._candidate_servers, self.connect_timeout, self.request_timeout,
        )
        self._api_factory = api_factory
        self._api: Any | None = None
        self._server_index = -1

    @property
    def client(self) -> TdxStandardClient:
        """兼容旧代码中的 ``quotes.client.get_*`` 调用。"""
        return self

    @property
    def connected(self) -> bool:
        """原生客户端已连接时返回 ``True``。"""
        return self._api is not None

    @property
    def current_server(self) -> tuple[str, int] | None:
        """返回当前原生连接的节点；尚未连接时返回 ``None``。"""
        if self._server_index < 0:
            return None
        return self.servers[self._server_index]

    def connect(self) -> None:
        """连接低延迟节点；候选较多时先并发探测并固定最快三个。"""
        if self.connected:
            return
        if len(self._candidate_servers) > _PREFERRED_SERVER_COUNT:
            errors = self._connect_preferred_servers()
        else:
            errors = self._connect_native(start=0)
        if self._api is None:
            raise ConnectionError("所有通达信标准行情服务器均不可达: " + "; ".join(errors[-3:]))

    def close(self) -> None:
        """关闭连接并清空节点状态；可重复调用。"""
        if self._api is not None:
            try:
                self._api.close()
            except Exception as exc:
                logger.debug("关闭标准行情连接失败: %s", exc)
        self._api = None
        self._server_index = -1

    def __enter__(self) -> TdxStandardClient:
        self.connect()
        return self

    def __exit__(self, *_args: object) -> None:
        self.close()

    def _new_api(self) -> Any:
        """创建带线程锁的原生协议客户端；节点重试由本类负责。"""
        return self._api_factory()

    def _connect_preferred_servers(self) -> list[str]:
        """复用用户目录排名；缓存过期或全部失效时自动重新测速。"""
        ranked_servers = self._ranking_cache.load()
        if ranked_servers is not None:
            self.servers = ranked_servers
            errors = self._connect_native(start=0)
            if self.connected:
                return errors
        return self._refresh_preferred_servers()

    def _refresh_preferred_servers(self) -> list[str]:
        """恢复完整候选列表，更新排名及持久化缓存。"""
        self.close()
        self._ranking_cache.invalidate()
        self.servers = self._candidate_servers
        errors = self._probe_and_keep_fastest_servers()
        if self.connected:
            self._ranking_cache.save(self.servers)
        return errors

    def _probe_and_keep_fastest_servers(self) -> list[str]:
        """并发执行真实协议探测，保留成功节点中延迟最低的三个。"""
        probes = self._probe_servers()
        successful = sorted(
            (probe for probe in probes if probe.api is not None),
            key=lambda probe: probe.latency,
        )
        selected = successful[:_PREFERRED_SERVER_COUNT]
        if selected:
            self._activate_selected_probes(selected, successful)
        return [self._format_probe_error(probe) for probe in probes if probe.error is not None]

    def _probe_servers(self) -> list[_ServerProbe]:
        """在受控线程数内探测全部候选节点。"""
        with ThreadPoolExecutor(
            max_workers=min(len(self.servers), _MAX_PROBE_WORKERS),
            thread_name_prefix="tdx-probe",
        ) as executor:
            return list(executor.map(self._probe_server, self.servers))

    def _probe_server(self, server: tuple[str, int]) -> _ServerProbe:
        """测量单节点从 TCP 建连到真实业务探测完成的总耗时。

        探测使用 K 线拉取而非轻量计数接口：坏节点往往仍能应答
        ``get_security_count``，却在真实业务请求上返回截断记录或空数据，
        轻探测无法识别（2026-09 实测三个坏节点全部通过轻探测）。
        """
        started_at = perf_counter()
        candidate: Any | None = None
        try:
            candidate = self._new_api()
            host, port = server
            candidate.connect(host, port, time_out=self.connect_timeout)
            if candidate.client is not None:
                candidate.client.settimeout(self.request_timeout)
            probe = candidate.get_security_count(1)
            if not isinstance(probe, int) or probe <= 0:
                raise OSError(f"行情探测返回异常: {probe!r}")
            bars = candidate.get_security_bars(9, 1, "999999", 0, 1)
            if not isinstance(bars, list) or not bars:
                raise OSError(f"K 线探测返回异常: {bars!r}")
            return _ServerProbe(server, perf_counter() - started_at, api=candidate)
        except Exception as exc:
            if candidate is not None:
                try:
                    candidate.close()
                except Exception:
                    pass
            return _ServerProbe(server, perf_counter() - started_at, error=exc)

    def _activate_selected_probes(
        self,
        selected: Sequence[_ServerProbe],
        successful: Sequence[_ServerProbe],
    ) -> None:
        """固定优选列表、复用最快连接并关闭其余测速连接。"""
        fastest = selected[0]
        self.servers = tuple(probe.server for probe in selected)
        self._api = fastest.api
        self._server_index = 0
        for probe in successful:
            if probe is fastest:
                continue
            candidate = probe.api
            if candidate is None:
                continue
            try:
                candidate.close()
            except Exception:
                pass
        logger.info(
            "通达信节点测速完成: %s",
            ", ".join(
                f"{probe.server[0]}:{probe.server[1]}={probe.latency * 1000:.1f}ms"
                for probe in selected
            ),
        )

    @staticmethod
    def _format_probe_error(probe: _ServerProbe) -> str:
        host, port = probe.server
        return f"{host}:{port}={probe.error}"

    def _connect_native(self, start: int) -> list[str]:
        """从 ``start`` 环形探测节点，返回失败摘要供最终异常使用。"""
        errors: list[str] = []
        for offset in range(len(self.servers)):
            index = (start + offset) % len(self.servers)
            host, port = self.servers[index]
            candidate = self._new_api()
            try:
                candidate.connect(host, port, time_out=self.connect_timeout)
                if candidate.client is not None:
                    candidate.client.settimeout(self.request_timeout)
                probe = candidate.get_security_count(1)
                # TCP connect 成功不代表节点能正确服务行情，轻量探测可提前
                # 排除握手兼容但业务请求已失效的节点。
                if not isinstance(probe, int) or probe <= 0:
                    raise OSError(f"行情探测返回异常: {probe!r}")
                bars = candidate.get_security_bars(9, 1, "999999", 0, 1)
                # 与 _probe_server 同口径：仅计数通过但 K 线截断/空返的坏节点
                # 必须在这里拦下，否则首次连接仍会落在坏节点上。
                if not isinstance(bars, list) or not bars:
                    raise OSError(f"K 线探测返回异常: {bars!r}")
                self._api = candidate
                self._server_index = index
                logger.info("连接原生通达信标准行情: %s:%d", host, port)
                return errors
            except Exception as exc:
                errors.append(f"{host}:{port}={exc}")
                try:
                    candidate.close()
                except Exception:
                    pass
        return errors

    def _request(self, method: str, *args: Any) -> Any:
        """执行请求，原生节点失败时轮换；全部不可达时抛出 ``ConnectionError``。"""
        if not self.connected:
            self.connect()
        attempted_servers: set[int] = set()
        last_error: Exception | None = None
        refreshed = False
        while True:
            if self._api is None or self._server_index in attempted_servers:
                if refreshed or len(self._candidate_servers) <= _PREFERRED_SERVER_COUNT:
                    break
                refreshed = True
                self._refresh_preferred_servers()
                attempted_servers.clear()
                if not self.connected:
                    break
            failed_index = self._server_index
            attempted_servers.add(failed_index)
            try:
                result = getattr(self._api, method)(*args)
                self._validate_result(method, result)
                if method == "get_security_quotes":
                    # 坏节点可能对五档请求返回空列表而非异常（2026-09 实测），
                    # 必须在轮换循环内校验才能触发节点切换。
                    self._validate_quotes_result(args[0] if args else [], result)
                return result
            except Exception as exc:
                last_error = exc
                failed_server = self.servers[failed_index]
                logger.warning(
                    "通达信请求失败，切换节点: method=%s server=%s:%d error=%s: %s",
                    method,
                    failed_server[0],
                    failed_server[1],
                    type(exc).__name__,
                    exc,
                )
                self.close()
                self._connect_native(start=(failed_index + 1) % len(self.servers))
        if last_error is not None:
            raise ConnectionError(
                f"通达信请求及节点切换失败: {method}; "
                f"last_error={type(last_error).__name__}: {last_error}"
            ) from last_error
        raise ConnectionError("通达信标准行情尚未连接")

    @staticmethod
    def _validate_result(method: str, result: Any) -> None:
        """拒绝会被误当作正常空数据的断链或畸形响应。"""
        if result is None:
            raise OSError(f"通达信返回空响应: {method}")
        if method == "get_security_count" and (not isinstance(result, int) or result < 0):
            raise ValueError(f"证券数量响应非法: {result!r}")
        if (
            method.startswith("get_")
            and method != "get_security_count"
            and not isinstance(result, (list, dict, bytes, str, pd.DataFrame))
        ):
            raise ValueError(f"通达信响应类型非法: {method}={type(result).__name__}")

    @staticmethod
    def _validate_quotes_result(symbols: Sequence[tuple[int, str]], result: Any) -> None:
        """坏节点对五档请求可能返回空列表而非异常（2026-09 实测）。

        合法场景（无效代码等）不应误伤：仅当全部代码都取不到任何行时
        判为节点异常，触发上层轮换；部分命中则按正常部分数据处理。
        """
        if isinstance(result, list) and symbols and not result:
            raise OSError(f"通达信五档行情返回空数据: {len(symbols)} 只代码 0 行")

    # ---- 原生协议低层接口（带输入边界） ----

    def get_security_count(self, market: int) -> int:
        """返回指定沪深市场的证券数量。"""
        _validate_market(market)
        return int(self._request("get_security_count", market))

    def get_security_list(self, market: int, start: int) -> list[dict]:
        """从 ``start`` 偏移读取一页证券元数据。"""
        _validate_market(market)
        if not 0 <= start <= 65535:
            raise ValueError(f"证券列表偏移越界: {start}")
        return list(self._request("get_security_list", market, start))

    def get_security_quotes(self, symbols: Sequence[tuple[int, str]]) -> list[dict]:
        """批量获取五档行情；协议单批最多支持 80 个代码。"""
        if not 1 <= len(symbols) <= 80:
            raise ValueError(f"五档行情单批数量必须为 1..80: {len(symbols)}")
        normalized = [(_validated_market(market), normalize_code(code)) for market, code in symbols]
        return list(self._request("get_security_quotes", normalized))

    def get_security_bars(
        self, category: int, market: int, code: str, start: int, count: int
    ) -> list[dict]:
        """获取证券 K 线，单页数量受标准行情协议限制。"""
        _validate_page(start, count, maximum=800)
        return list(
            self._request(
                "get_security_bars",
                int(category),
                _validated_market(market),
                normalize_code(code),
                start,
                count,
            )
        )

    def get_index_bars(
        self, category: int, market: int, code: str, start: int, count: int
    ) -> list[dict]:
        """获取指数 K 线；指数必须走独立消息类型。"""
        _validate_page(start, count, maximum=800)
        return list(
            self._request(
                "get_index_bars",
                int(category),
                _validated_market(market),
                normalize_code(code),
                start,
                count,
            )
        )

    def get_minute_time_data(self, market: int, code: str) -> list[dict]:
        """获取证券当日分时。"""
        return list(
            self._request("get_minute_time_data", _validated_market(market), normalize_code(code))
        )

    def get_history_minute_time_data(self, market: int, code: str, date: str | int) -> list[dict]:
        """获取指定 ``YYYYMMDD`` 交易日的历史分时。"""
        date_value = _validate_date(date)
        return list(
            self._request(
                "get_history_minute_time_data",
                _validated_market(market),
                normalize_code(code),
                date_value,
            )
        )

    def get_transaction_data(self, market: int, code: str, start: int, count: int) -> list[dict]:
        """分页获取当日逐笔成交。"""
        _validate_page(start, count, maximum=2000)
        return list(
            self._request(
                "get_transaction_data",
                _validated_market(market),
                normalize_code(code),
                start,
                count,
            )
        )

    def get_history_transaction_data(
        self, market: int, code: str, start: int, count: int, date: str | int
    ) -> list[dict]:
        """分页获取指定 ``YYYYMMDD`` 交易日的逐笔成交。"""
        _validate_page(start, count, maximum=2000)
        return list(
            self._request(
                "get_history_transaction_data",
                _validated_market(market),
                normalize_code(code),
                start,
                count,
                _validate_date(date),
            )
        )

    def get_company_info_category(self, market: int, code: str) -> list[dict]:
        """获取 F10 文件的分类与字节范围目录。"""
        return list(
            self._request(
                "get_company_info_category", _validated_market(market), normalize_code(code)
            )
        )

    def get_company_info_content(
        self, market: int, code: str, filename: str, start: int, length: int
    ) -> str:
        """按目录给出的文件名和字节范围读取 F10 正文。"""
        if start < 0 or length <= 0:
            raise ValueError("F10 内容范围非法")
        return str(
            self._request(
                "get_company_info_content",
                _validated_market(market),
                normalize_code(code),
                str(filename),
                start,
                length,
            )
        )

    def get_xdxr_info(self, market: int, code: str) -> list[dict]:
        """获取除权除息事件。"""
        return list(self._request("get_xdxr_info", _validated_market(market), normalize_code(code)))

    def get_finance_info(self, market: int, code: str) -> dict:
        """获取最新财务快照。"""
        result = self._request("get_finance_info", _validated_market(market), normalize_code(code))
        return dict(result)

    # ---- 兼容原 StdQuotes 的高层接口 ----

    def stocks(self, market: int = 1) -> pd.DataFrame:
        """分页读取指定市场的全部证券，并转换为兼容 DataFrame。"""
        count = self.get_security_count(market)
        rows: list[dict] = []
        for start in range(0, count, 1000):
            page = self.get_security_list(market, start)
            rows.extend(page)
            if len(page) < 1000:
                break
        return _to_frame(rows)

    def quotes(self, symbol: Sequence[str] | str | None = None, **_kwargs: Any) -> pd.DataFrame:
        """兼容旧接口的单个或批量五档行情入口。"""
        if symbol is None:
            return pd.DataFrame()
        values = [symbol] if isinstance(symbol, str) else list(symbol)
        pairs = [(market_of(value), normalize_code(value)) for value in values]
        return _to_frame(self.get_security_quotes(pairs))

    def minute(self, symbol: str, **_kwargs: Any) -> pd.DataFrame:
        """兼容旧接口的当日分时入口。"""
        code = normalize_code(symbol)
        return _to_frame(self.get_minute_time_data(market_of(symbol), code))

    def minutes(self, symbol: str, date: str, **_kwargs: Any) -> pd.DataFrame:
        """兼容旧接口的历史分时入口。"""
        code = normalize_code(symbol)
        return _to_frame(self.get_history_minute_time_data(market_of(symbol), code, date))

    def transaction(
        self, symbol: str, start: int = 0, offset: int = 10, **_kwargs: Any
    ) -> pd.DataFrame:
        """兼容旧接口的当日逐笔入口；``offset`` 表示返回条数。"""
        code = normalize_code(symbol)
        return _to_frame(self.get_transaction_data(market_of(symbol), code, start, offset))

    def transactions(
        self, symbol: str, start: int = 0, offset: int = 10, date: str | None = None, **_kwargs: Any
    ) -> pd.DataFrame:
        """兼容旧接口的统一逐笔入口；日期为空时读取当日。"""
        if date is None:
            return self.transaction(symbol, start=start, offset=offset)
        code = normalize_code(symbol)
        return _to_frame(
            self.get_history_transaction_data(market_of(symbol), code, start, offset, date)
        )

    def xdxr(self, symbol: str, **_kwargs: Any) -> pd.DataFrame:
        """以兼容 DataFrame 返回除权除息事件。"""
        code = normalize_code(symbol)
        return _to_frame(self.get_xdxr_info(market_of(symbol), code))

    def finance(self, symbol: str, **_kwargs: Any) -> pd.DataFrame:
        """以兼容 DataFrame 返回财务快照。"""
        code = normalize_code(symbol)
        return _to_frame(self.get_finance_info(market_of(symbol), code))

    def F10(self, symbol: str, name: str = "") -> dict[str, str] | str | None:  # noqa: N802
        """返回全部 F10 分类正文，或由 ``name`` 选择单个分类。"""
        code = normalize_code(symbol)
        market = market_of(symbol)
        categories = self.get_company_info_category(market, code)
        if not categories:
            return None
        result: dict[str, str] = {}
        for item in categories:
            if name and item.get("name") != name:
                continue
            content = self.get_company_info_content(
                market, code, item["filename"], int(item["start"]), int(item["length"])
            )
            if name:
                return content
            result[str(item["name"])] = content
        return result


def _validate_market(market: int) -> None:
    """校验标准行情市场号。"""
    if market not in (0, 1):
        raise ValueError(f"标准行情仅支持沪深市场: {market}")


def _validated_market(market: int) -> int:
    """校验并返回市场号，便于在请求参数表达式中使用。"""
    _validate_market(market)
    return market


def _validate_page(start: int, count: int, *, maximum: int) -> None:
    """校验协议分页边界，防止整数截断或服务器拒绝请求。"""
    if start < 0 or not 1 <= count <= maximum:
        raise ValueError(f"请求范围非法: start={start}, count={count}, max={maximum}")


def _validate_date(date: str | int) -> int:
    """校验 ``YYYYMMDD`` 并转换为协议整数。"""
    value = str(date)
    if _DATE_RE.fullmatch(value) is None:
        raise ValueError(f"日期必须为 YYYYMMDD: {date}")
    return int(value)
