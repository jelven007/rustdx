"""分笔组命令：trades。"""

from __future__ import annotations

from typing import Annotated, Optional

import typer

import tdx_cli.cli as cli_root
from tdx_cli.cli.common import SymbolArg, run as _run


def trades(
    symbol: SymbolArg,
    date: Annotated[Optional[str], typer.Option("--date", help="交易日 YYYYMMDD（缺省当日）")] = None,
    count: Annotated[int, typer.Option("--count", help="条数", min=1)] = 2000,
    market: Annotated[Optional[int], typer.Option("--market", help="市场 0=SZ 1=SH")] = None,
    fmt: cli_root.FormatOpt = None,
    output: cli_root.OutputOpt = None,
    host: cli_root.HostOpt = None,
    port: cli_root.PortOpt = None,
    config: cli_root.ConfigOpt = None,
) -> None:
    """逐笔成交（当日或历史）"""
    _run(
        lambda c: c.trades(symbol=symbol, count=count, date=date, market=market),
        fmt=fmt, path=output, host=host, port=port, config=config,
    )
