"""文件组命令：report-file / zhb-files。"""

from __future__ import annotations

from pathlib import Path
from typing import Annotated, Optional

import typer

import tdx_cli.cli as cli_root
from tdx_cli.cli.common import run as _run


def report_file(
    filename: Annotated[str, typer.Argument(help="报表/配置文件名，如 tdxzs.cfg")],
    output: cli_root.OutputOpt = None,
    host: cli_root.HostOpt = None,
    port: cli_root.PortOpt = None,
    config: cli_root.ConfigOpt = None,
) -> None:
    """下载通达信报表/配置文件（必须 -o，原样字节写盘）"""
    if output is None:
        raise typer.BadParameter("二进制文件必须用 -o 指定输出路径")
    _run(
        lambda c: c.report_file(filename),
        fmt=None, path=output, host=host, port=port, config=config,
        need_protocol=True,
    )


def zhb_files(
    output: Annotated[Optional[Path], typer.Option("-o", "--output", help="输出目录（缺省当前目录）")] = None,
    host: cli_root.HostOpt = None,
    port: cli_root.PortOpt = None,
    config: cli_root.ConfigOpt = None,
) -> None:
    """下载板块配置总包并解出全部文件"""
    out_dir = output if output else Path.cwd()
    out_dir.mkdir(parents=True, exist_ok=True)

    def handler(client):
        files = client.zhb_files()
        for name, payload in files.items():
            (out_dir / name).write_bytes(payload)
        return sorted(files)

    _run(handler, fmt=None, path=None, host=host, port=port, config=config, need_protocol=True)
