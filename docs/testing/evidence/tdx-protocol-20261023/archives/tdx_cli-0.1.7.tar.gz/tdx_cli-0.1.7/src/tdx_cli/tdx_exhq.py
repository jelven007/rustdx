"""通达信扩展行情客户端：期货、期权、港股、外汇与全球指数。

Python 实现以仓库内 ``tdx-master/protocol/model_ex.go`` 的帧结构和字段布局为
基准，连接策略与节点列表对应 ``tdx-master/client_exhq.go`` 和
``tdx-master/hosts_exhq.go``。后续协议升级应先同步这些来源及其测试，再修改本模块。
"""

from __future__ import annotations

import socket
import struct
import zlib
from dataclasses import dataclass

EXHQ_SERVERS = [
    ("116.205.143.214", 7727),
    ("124.71.223.19", 7727),
    ("113.45.175.47", 7727),
    ("175.24.47.69", 7727),
    ("150.158.9.199", 7727),
    ("150.158.20.127", 7727),
    ("49.235.119.116", 7727),
]

# 消息号与固定握手数据对应 tdx-master/protocol/model_ex.go。集中定义在此处，
# 让 Python 与 Go 参考实现可以逐项核对，也避免业务方法散落十六进制字面量。
TYPE_SETUP = 0x2454
TYPE_MARKETS = 0x23F4
TYPE_COUNT = 0x23F0
TYPE_INSTRUMENT = 0x23F5
TYPE_QUOTE = 0x23FA
TYPE_QUOTE_LIST = 0x2400
TYPE_BARS = 0x23FF
TYPE_MINUTE = 0x240B
TYPE_HISTORY_MINUTE = 0x240C
TYPE_TRADE = 0x23FC
TYPE_HISTORY_TRADE = 0x2406
TYPE_BARS_RANGE = 0x240D

_RESPONSE_PREFIX = bytes.fromhex("b1cb7400")
_SETUP_DATA = bytes.fromhex("1f32c6e5d53dfb41") * 8 + bytes.fromhex(
    "cce16dffd5ba3fb8cbc57a054f7748ea"
)


@dataclass(frozen=True)
class ExMarket:
    """扩展行情市场元数据；``market`` 是后续请求使用的协议市场号。"""

    market: int
    category: int
    name: str
    short_name: str


@dataclass(frozen=True)
class ExInstrument:
    """扩展市场中的可交易合约或指数。"""

    category: int
    market: int
    code: str
    name: str
    description: str


@dataclass(frozen=True)
class ExQuote:
    """单个扩展品种的盘口快照。"""

    market: int
    code: str
    pre_close: float
    open: float
    high: float
    low: float
    price: float
    open_interest: int
    total_volume: int
    current_volume: int
    inner_volume: int
    outer_volume: int
    position: int
    bid: tuple[float, ...]
    bid_volume: tuple[int, ...]
    ask: tuple[float, ...]
    ask_volume: tuple[int, ...]


@dataclass(frozen=True)
class ExQuoteListItem:
    """批量行情中的精简盘口记录。"""

    market: int
    code: str
    pre_close: float
    open: float
    high: float
    low: float
    price: float
    total_volume: int
    amount: float
    inner_volume: int
    outer_volume: int
    position: int
    bid: tuple[float, ...]
    bid_volume: tuple[int, ...]
    ask: tuple[float, ...]
    ask_volume: tuple[int, ...]


@dataclass(frozen=True)
class ExBar:
    """扩展品种 K 线；期货用 ``position`` 表示持仓量。"""

    datetime: str
    open: float
    high: float
    low: float
    close: float
    position: int
    volume: int
    settlement_price: float
    amount: float = 0.0


@dataclass(frozen=True)
class ExMinuteTick:
    """分时行情记录。"""

    hour: int
    minute: int
    price: float
    average_price: float
    volume: int
    open_interest: int


@dataclass(frozen=True)
class ExTradeTick:
    """逐笔成交记录；``direction`` 为 1 买、-1 卖、0 未知。"""

    hour: int
    minute: int
    second: int
    price: int
    volume: int
    position_change: int
    nature: int
    nature_name: str
    direction: int


class ExHqClient:
    """同步扩展行情 TCP 客户端。"""

    def __init__(
        self,
        servers: list[tuple[str, int]] | None = None,
        connect_timeout: float = 1.5,
        request_timeout: float = 8.0,
    ):
        self.servers = servers or EXHQ_SERVERS
        self.connect_timeout = connect_timeout
        self.request_timeout = request_timeout
        self._socket: socket.socket | None = None
        self._msg_id = 0

    def __enter__(self) -> ExHqClient:
        self.connect()
        return self

    def __exit__(self, *_args: object) -> None:
        self.close()

    def connect(self) -> None:
        """按配置顺序连接节点，并用初始化请求验证协议可用性。"""
        errors: list[str] = []
        for host, port in self.servers:
            sock: socket.socket | None = None
            try:
                sock = socket.create_connection((host, port), timeout=self.connect_timeout)
                sock.settimeout(self.request_timeout)
                self._socket = sock
                self._request(TYPE_SETUP, _SETUP_DATA)
                return
            except (OSError, TimeoutError, ValueError, zlib.error) as exc:
                errors.append(f"{host}:{port}={exc}")
                if sock is not None:
                    sock.close()
                self._socket = None
        raise ConnectionError("所有通达信扩展行情服务器均不可达: " + "; ".join(errors[-3:]))

    def close(self) -> None:
        """关闭当前 TCP 连接；可重复调用。"""
        if self._socket is not None:
            self._socket.close()
            self._socket = None

    def markets(self) -> list[ExMarket]:
        """读取服务器支持的扩展市场代码表。"""
        data = self._request(TYPE_MARKETS)
        if len(data) < 2:
            return []
        count = struct.unpack_from("<H", data)[0]
        result: list[ExMarket] = []
        position = 2
        for _ in range(count):
            if position + 64 > len(data):
                break
            category = data[position]
            name = _gbk(data[position + 1 : position + 33])
            market = data[position + 33]
            short_name = _gbk(data[position + 34 : position + 36])
            if category or market:
                result.append(ExMarket(market, category, name, short_name))
            position += 64
        return result

    def count(self) -> int:
        """返回扩展行情服务器中的合约总数。"""
        data = self._request(TYPE_COUNT)
        return struct.unpack_from("<I", data, 19)[0] if len(data) >= 23 else 0

    def instruments(self, start: int = 0, count: int = 100) -> list[ExInstrument]:
        """分页读取合约列表；服务端每条记录固定占 64 字节。"""
        data = self._request(TYPE_INSTRUMENT, struct.pack("<IH", start, count))
        if len(data) < 6:
            return []
        item_count = struct.unpack_from("<H", data, 4)[0]
        result: list[ExInstrument] = []
        position = 6
        for _ in range(item_count):
            if position + 64 > len(data):
                break
            result.append(
                ExInstrument(
                    category=data[position],
                    market=data[position + 1],
                    code=_gbk(data[position + 5 : position + 14]),
                    name=_gbk(data[position + 14 : position + 31]),
                    description=_gbk(data[position + 31 : position + 40]),
                )
            )
            position += 64
        return result

    def quote(self, market: int, code: str) -> ExQuote:
        """获取单个扩展品种的五档行情。"""
        data = self._request(TYPE_QUOTE, bytes([market]) + _code(code))
        # 前 14 字节是市场、代码及协议保留区，报价字段从偏移 14 开始。
        reader = _Reader(data, 14)
        pre_close, open_price, high, low, price = (reader.f32() for _ in range(5))
        open_interest = reader.u32()
        reader.skip(4)
        total_volume, current_volume = reader.u32(), reader.u32()
        reader.skip(4)
        inner_volume, outer_volume = reader.u32(), reader.u32()
        reader.skip(4)
        position = reader.u32()
        bid = tuple(reader.f32() for _ in range(5))
        bid_volume = tuple(reader.u32() for _ in range(5))
        ask = tuple(reader.f32() for _ in range(5))
        ask_volume = tuple(reader.u32() for _ in range(5))
        return ExQuote(
            data[0], _gbk(data[1:10]), pre_close, open_price, high, low, price,
            open_interest, total_volume, current_volume, inner_volume, outer_volume,
            position, bid, bid_volume, ask, ask_volume,
        )

    def quote_list(
        self, market: int, category: int, start: int = 0, count: int = 100
    ) -> list[ExQuoteListItem]:
        """批量行情；``category`` 2=港股、3=期货。"""
        if category not in {2, 3}:
            raise ValueError("批量扩展行情目前仅支持港股(category=2)和期货(category=3)")
        payload = bytes([market]) + struct.pack("<HHHH", 0, start, count, 1)
        data = self._request(TYPE_QUOTE_LIST, payload, control=2)
        if len(data) < 2:
            return []
        item_count = struct.unpack_from("<H", data)[0]
        result: list[ExQuoteListItem] = []
        position = 2
        for _ in range(item_count):
            if position + 300 > len(data):
                break
            item_market = data[position]
            code = _gbk(data[position + 1 : position + 10])
            reader = _Reader(data, position + 10)
            if category == 2:
                item = _parse_hk_quote_list_item(reader, item_market, code)
            else:
                item = _parse_futures_quote_list_item(reader, item_market, code)
            result.append(item)
            position += 300
        return result

    def bars(
        self, category: int, market: int, code: str, start: int = 0, count: int = 100
    ) -> list[ExBar]:
        """分页获取 K 线；``category`` 决定周期及时间字段的编码方式。"""
        payload = bytes([market]) + _code(code) + struct.pack("<HHIH", category, 1, start, count)
        data = self._request(TYPE_BARS, payload)
        if len(data) < 20:
            return []
        item_count = struct.unpack_from("<H", data, 18)[0]
        reader = _Reader(data, 20)
        result: list[ExBar] = []
        for _ in range(item_count):
            if reader.remaining < 32:
                break
            raw_time = reader.read(4)
            open_price, high, low, close = (reader.f32() for _ in range(4))
            raw_position = reader.read(4)
            # 同一槽位在期货响应中是持仓量，部分指数响应中却是成交额浮点数。
            # 两种解释都保留，由调用方按品种类型选用，避免协议层臆测。
            position = struct.unpack("<I", raw_position)[0]
            amount = float(struct.unpack("<f", raw_position)[0])
            volume = reader.u32()
            settlement = reader.f32()
            result.append(
                ExBar(_decode_bar_time(raw_time, category), open_price, high, low, close,
                      position, volume, settlement, amount)
            )
        return result

    def minute(self, market: int, code: str, date: int | None = None) -> list[ExMinuteTick]:
        """获取实时或历史分时；历史日期使用 ``YYYYMMDD`` 整数。"""
        if date is None:
            data = self._request(TYPE_MINUTE, bytes([market]) + _code(code))
            header_length = 12
        else:
            data = self._request(
                TYPE_HISTORY_MINUTE, struct.pack("<I", date) + bytes([market]) + _code(code)
            )
            header_length = 20
        return _parse_minutes(data, header_length)

    def trades(
        self,
        market: int,
        code: str,
        start: int = 0,
        count: int = 100,
        date: int | None = None,
    ) -> list[ExTradeTick]:
        """获取实时或历史逐笔成交。"""
        if date is None:
            payload = bytes([market]) + _code(code) + struct.pack("<IH", start, count)
            data = self._request(TYPE_TRADE, payload)
        else:
            payload = (
                struct.pack("<I", date)
                + bytes([market])
                + _code(code)
                + struct.pack("<IH", start, count)
            )
            data = self._request(TYPE_HISTORY_TRADE, payload)
        return _parse_trades(data, market)

    def bars_range(self, market: int, code: str, date: int, end_date: int) -> list[ExBar]:
        """按闭区间日期获取日 K，日期格式为 ``YYYYMMDD`` 整数。"""
        payload = bytes([market]) + _code(code) + b"\x07\x00" + struct.pack(
            "<II", date, end_date
        )
        data = self._request(TYPE_BARS_RANGE, payload)
        if len(data) < 14:
            return []
        count = struct.unpack_from("<H", data, 12)[0]
        reader = _Reader(data, 14)
        result: list[ExBar] = []
        for _ in range(count):
            if reader.remaining < 32:
                break
            day, minute = reader.u16(), reader.u16()
            prices = [reader.f32() for _ in range(4)]
            position, volume, settlement = reader.u32(), reader.u32(), reader.f32()
            year, rest = day // 2048 + 2004, day % 2048
            result.append(
                ExBar(
                    f"{year:04d}-{rest // 100:02d}-{rest % 100:02d} "
                    f"{minute // 60:02d}:{minute % 60:02d}",
                    *prices, position, volume, settlement,
                )
            )
        return result

    def _request(self, message_type: int, data: bytes = b"", control: int = 1) -> bytes:
        """发送一次请求，并忽略同一连接中迟到的其他请求响应。"""
        if self._socket is None:
            raise ConnectionError("扩展行情客户端尚未连接")
        self._msg_id += 1
        message_id = self._msg_id
        self._socket.sendall(_frame(message_id, message_type, data, control))
        while True:
            response_id, response_type, response_data = self._read_response()
            if response_id == message_id:
                if response_type != message_type:
                    raise ValueError(f"扩展行情响应类型不匹配: {response_type:#x}/{message_type:#x}")
                return response_data

    def _read_response(self) -> tuple[int, int, bytes]:
        """从字节流重新同步帧头，读取并按协议标记解压响应。"""
        if self._socket is None:
            raise ConnectionError("扩展行情客户端尚未连接")
        window = bytearray()
        while bytes(window) != _RESPONSE_PREFIX:
            window.extend(_recv_exact(self._socket, 1))
            if len(window) > 4:
                del window[0]
        header = _recv_exact(self._socket, 12)
        message_id = struct.unpack_from("<I", header, 1)[0]
        message_type, compressed_length, raw_length = struct.unpack_from("<HHH", header, 6)
        payload = _recv_exact(self._socket, compressed_length)
        result = zlib.decompress(payload) if compressed_length != raw_length else payload
        if len(result) != raw_length:
            raise ValueError("扩展行情响应解压长度不匹配")
        return message_id, message_type, result


def _frame(message_id: int, message_type: int, data: bytes, control: int = 1) -> bytes:
    """编码扩展行情请求帧。"""
    length = len(data) + 2
    return b"\x01" + struct.pack("<IBHHH", message_id, control, length, length, message_type) + data


def _code(code: str) -> bytes:
    """将品种代码编码为协议要求的 9 字节 GBK 定长字段。"""
    encoded = code.encode("gbk")
    if len(encoded) > 9:
        raise ValueError(f"扩展行情代码过长: {code}")
    return encoded.ljust(9, b"\0")


def _gbk(data: bytes) -> str:
    """解码以 NUL 结尾的 GBK 定长字符串。"""
    return data.split(b"\0", 1)[0].decode("gbk", errors="replace")


def _decode_bar_time(data: bytes, category: int) -> str:
    """按 K 线类别解码压缩日期，返回稳定的 ISO 风格时间。"""
    if category in {0, 1, 2, 3, 7, 8}:
        day, minute = struct.unpack("<HH", data)
        year, rest = (day >> 11) + 2004, day % 2048
        return f"{year:04d}-{rest // 100:02d}-{rest % 100:02d} {minute // 60:02d}:{minute % 60:02d}"
    raw = struct.unpack("<I", data)[0]
    return f"{raw // 10000:04d}-{raw % 10000 // 100:02d}-{raw % 100:02d} 15:00"


def _parse_minutes(data: bytes, header_length: int) -> list[ExMinuteTick]:
    """解析实时与历史分时共用的记录区。"""
    if len(data) < header_length:
        return []
    count = struct.unpack_from("<H", data, header_length - 2)[0]
    reader = _Reader(data, header_length)
    result: list[ExMinuteTick] = []
    for _ in range(count):
        if reader.remaining < 18:
            break
        minute = reader.u16()
        result.append(
            ExMinuteTick(
                minute // 60, minute % 60, reader.f32(), reader.f32(), reader.u32(), reader.u32()
            )
        )
    return result


def _parse_trades(data: bytes, market: int) -> list[ExTradeTick]:
    """解析逐笔记录，并将市场相关的成交性质归一化。"""
    if len(data) < 16:
        return []
    count = struct.unpack_from("<H", data, 14)[0]
    reader = _Reader(data, 16)
    result: list[ExTradeTick] = []
    for _ in range(count):
        if reader.remaining < 16:
            break
        minute, price, volume, change, nature = (
            reader.u16(), reader.u32(), reader.u32(), reader.i32(), reader.u16()
        )
        direction, name = _trade_nature(market, nature, volume, change)
        second = nature % 10000
        result.append(
            ExTradeTick(minute // 60, minute % 60, second if second <= 59 else 0,
                        price, volume, change, nature, name, direction)
        )
    return result


def _trade_nature(market: int, nature: int, volume: int, change: int) -> tuple[int, str]:
    """将不同市场复用的 ``nature`` 位域转换为方向和中文成交性质。"""
    if market in {31, 48}:
        return (1, "B") if nature == 0 else ((-1, "S") if nature == 256 else (0, ""))
    direction = 1 if nature // 10000 == 0 else -1 if nature // 10000 == 1 else 0
    if change > 0:
        name = "双开" if volume == change else ("多开" if direction > 0 else "空开")
    elif change < 0:
        name = "双平" if volume == -change else ("空平" if direction > 0 else "多平")
    else:
        name = "多换" if direction > 0 else "空换" if direction < 0 else "换手"
    return direction, name


def _parse_hk_quote_list_item(
    reader: _Reader, market: int, code: str
) -> ExQuoteListItem:
    """解析批量响应中的港股 300 字节记录。"""
    reader.skip(4)
    pre_close, open_price, high, low, price = (reader.f32() for _ in range(5))
    reader.skip(8)
    total_volume = reader.u32()
    reader.skip(4)
    amount = reader.f32()
    reader.skip(8)
    inner_volume, outer_volume = reader.u32(), reader.u32()
    bid = tuple(reader.f32() for _ in range(5))
    bid_volume = tuple(reader.u32() for _ in range(5))
    ask = tuple(reader.f32() for _ in range(5))
    ask_volume = tuple(reader.u32() for _ in range(5))
    return ExQuoteListItem(
        market, code, pre_close, open_price, high, low, price, total_volume, amount,
        inner_volume, outer_volume, 0, bid, bid_volume, ask, ask_volume,
    )


def _parse_futures_quote_list_item(
    reader: _Reader, market: int, code: str
) -> ExQuoteListItem:
    """解析批量响应中的期货 300 字节记录。"""
    reader.skip(4)
    pre_close, open_price, high, low, price = (reader.f32() for _ in range(5))
    reader.skip(8)
    total_volume = reader.u32()
    reader.skip(4)
    amount = reader.f32()
    inner_volume, outer_volume = reader.u32(), reader.u32()
    reader.skip(4)
    position = reader.u32()
    ask1 = reader.f32()
    reader.skip(16)
    ask_volume1 = reader.u32()
    return ExQuoteListItem(
        market, code, pre_close, open_price, high, low, price, total_volume, amount,
        inner_volume, outer_volume, position, (), (), (ask1,), (ask_volume1,),
    )


def _recv_exact(sock: socket.socket, size: int) -> bytes:
    """读取恰好 ``size`` 字节，避免 TCP 分包造成半帧解析。"""
    result = bytearray()
    while len(result) < size:
        chunk = sock.recv(size - len(result))
        if not chunk:
            raise ConnectionError("扩展行情服务器提前关闭连接")
        result.extend(chunk)
    return bytes(result)


class _Reader:
    """带游标的小端二进制读取器，统一维护协议字段偏移。"""

    def __init__(self, data: bytes, position: int = 0):
        self.data = data
        self.position = position

    @property
    def remaining(self) -> int:
        return len(self.data) - self.position

    def read(self, size: int) -> bytes:
        """读取指定长度并推进游标。"""
        value = self.data[self.position : self.position + size]
        self.position += size
        return value

    def skip(self, size: int) -> None:
        """跳过协议保留字段。"""
        self.position += size

    def u16(self) -> int:
        return struct.unpack("<H", self.read(2))[0]

    def u32(self) -> int:
        return struct.unpack("<I", self.read(4))[0]

    def i32(self) -> int:
        return struct.unpack("<i", self.read(4))[0]

    def f32(self) -> float:
        return float(struct.unpack("<f", self.read(4))[0])
