"""板块组命令。"""

from __future__ import annotations

from typing import Annotated

import typer

import tdx_cli.cli as cli_root
from tdx_cli.cli.common import run as _run


def blocks(
    category: Annotated[str, typer.Argument(help="板块类别: concept/style/index/industry")],
    fmt: cli_root.FormatOpt = None,
    output: cli_root.OutputOpt = None,
    host: cli_root.HostOpt = None,
    port: cli_root.PortOpt = None,
    config: cli_root.ConfigOpt = None,
) -> None:
    """板块成分（概念/风格/指数/行业）"""
    if category not in ("concept", "style", "index", "industry"):
        raise typer.BadParameter(f"无效类别 {category}，可选: concept/style/index/industry")
    _run(
        lambda c: c.blocks(category),
        fmt=fmt, path=output, host=host, port=port, config=config,
        need_protocol=True,
    )


def block(
    filename: Annotated[str, typer.Argument(help="板块文件名，如 block_gn.dat")],
    with_index: Annotated[bool, typer.Option("--with-index/--no-index", help="不取板块指数成分")] = True,
    fmt: cli_root.FormatOpt = None,
    output: cli_root.OutputOpt = None,
    host: cli_root.HostOpt = None,
    port: cli_root.PortOpt = None,
    config: cli_root.ConfigOpt = None,
) -> None:
    """按文件名取板块成分"""
    _run(
        lambda c: c.block(filename, with_index=with_index),
        fmt=fmt, path=output, host=host, port=port, config=config,
        need_protocol=True,
    )


def special_blocks(fmt: cli_root.FormatOpt = None, output: cli_root.OutputOpt = None, host: cli_root.HostOpt = None, port: cli_root.PortOpt = None, config: cli_root.ConfigOpt = None) -> None:
    """大型专业板块（中证2000 等）"""
    _run(lambda c: c.special_blocks(), fmt=fmt, path=output, host=host, port=port, config=config, need_protocol=True)


def industry_assignments(fmt: cli_root.FormatOpt = None, output: cli_root.OutputOpt = None, host: cli_root.HostOpt = None, port: cli_root.PortOpt = None, config: cli_root.ConfigOpt = None) -> None:
    """全市场行业归属"""
    _run(lambda c: c.industry_assignments(), fmt=fmt, path=output, host=host, port=port, config=config, need_protocol=True)


def stock_stats(fmt: cli_root.FormatOpt = None, output: cli_root.OutputOpt = None, host: cli_root.HostOpt = None, port: cli_root.PortOpt = None, config: cli_root.ConfigOpt = None) -> None:
    """个股估值/涨跌幅统计"""
    _run(lambda c: c.stock_stats(), fmt=fmt, path=output, host=host, port=port, config=config, need_protocol=True)


def stock_stats2(fmt: cli_root.FormatOpt = None, output: cli_root.OutputOpt = None, host: cli_root.HostOpt = None, port: cli_root.PortOpt = None, config: cli_root.ConfigOpt = None) -> None:
    """个股成交额等扩展统计"""
    _run(lambda c: c.stock_stats2(), fmt=fmt, path=output, host=host, port=port, config=config, need_protocol=True)


def ipo_subscriptions(fmt: cli_root.FormatOpt = None, output: cli_root.OutputOpt = None, host: cli_root.HostOpt = None, port: cli_root.PortOpt = None, config: cli_root.ConfigOpt = None) -> None:
    """新股申购列表"""
    _run(lambda c: c.ipo_subscriptions(), fmt=fmt, path=output, host=host, port=port, config=config, need_protocol=True)


def index_definitions(fmt: cli_root.FormatOpt = None, output: cli_root.OutputOpt = None, host: cli_root.HostOpt = None, port: cli_root.PortOpt = None, config: cli_root.ConfigOpt = None) -> None:
    """板块指数定义（名称/代码/类型）"""
    _run(lambda c: c.tdx_index_definitions(), fmt=fmt, path=output, host=host, port=port, config=config, need_protocol=True)


def block_aliases(fmt: cli_root.FormatOpt = None, output: cli_root.OutputOpt = None, host: cli_root.HostOpt = None, port: cli_root.PortOpt = None, config: cli_root.ConfigOpt = None) -> None:
    """板块简称/全称映射"""
    _run(lambda c: c.tdx_block_aliases(), fmt=fmt, path=output, host=host, port=port, config=config, need_protocol=True)
