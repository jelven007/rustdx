"""K线组命令：kline / minute / minutes / minute-history / index-bars / auction。"""

from __future__ import annotations

from typing import Annotated

import typer

import tdx_cli.cli as cli_root
from tdx_cli.cli.common import CountOpt, MarketOpt, SymbolArg, run
from tdx_cli.tdx import Frequency

_FREQ_VALUES = {
    "1m": Frequency.MINUTE_1,
    "5m": Frequency.MINUTE_5,
    "15m": Frequency.MINUTE_15,
    "30m": Frequency.MINUTE_30,
    "1h": Frequency.HOUR_1,
    "day": Frequency.DAY,
    "week": Frequency.WEEK,
    "month": Frequency.MONTH,
    "year": Frequency.YEAR,
}


def _frequency_callback(value: str) -> int:
    if value not in _FREQ_VALUES:
        raise typer.BadParameter(
            f"无效频率 {value}，可选: {'/'.join(_FREQ_VALUES)}"
        )
    return _FREQ_VALUES[value]


FreqOpt = Annotated[
    str,
    typer.Option(
        "--freq",
        callback=_frequency_callback,
        help="K线频率: 1m/5m/15m/30m/1h/day/week/month/year",
    ),
]


def kline(
    symbol: SymbolArg,
    freq: FreqOpt = "day",
    count: CountOpt = 100,
    adjust: Annotated[str, typer.Option(help="复权: none/qfq/hfq")] = "none",
    market: MarketOpt = None,
    fmt: cli_root.FormatOpt = None,
    output: cli_root.OutputOpt = None,
    host: cli_root.HostOpt = None,
    port: cli_root.PortOpt = None,
    config: cli_root.ConfigOpt = None,
) -> None:
    """K线（支持前/后复权）"""
    if adjust not in ("none", "qfq", "hfq"):
        raise typer.BadParameter(f"无效复权 {adjust}，可选: none/qfq/hfq")
    run(
        lambda c: c.kline(
            symbol=symbol,
            frequency=freq,
            count=count,
            adjustment=adjust,
            market=market,
        ),
        fmt=fmt, path=output, host=host, port=port, config=config,
    )


def minute(
    symbol: SymbolArg,
    market: MarketOpt = None,
    fmt: cli_root.FormatOpt = None,
    output: cli_root.OutputOpt = None,
    host: cli_root.HostOpt = None,
    port: cli_root.PortOpt = None,
    config: cli_root.ConfigOpt = None,
) -> None:
    """当日分时"""
    run(
        lambda c: c.minute(symbol=symbol, market=market),
        fmt=fmt, path=output, host=host, port=port, config=config,
    )


def minutes(
    symbol: SymbolArg,
    date: Annotated[str, typer.Option(help="交易日 YYYYMMDD")],
    market: MarketOpt = None,
    fmt: cli_root.FormatOpt = None,
    output: cli_root.OutputOpt = None,
    host: cli_root.HostOpt = None,
    port: cli_root.PortOpt = None,
    config: cli_root.ConfigOpt = None,
) -> None:
    """历史单日分时"""
    run(
        lambda c: c.minutes(symbol=symbol, date=date, market=market),
        fmt=fmt, path=output, host=host, port=port, config=config,
    )


def minute_history(
    symbol: SymbolArg,
    date: Annotated[str, typer.Option(help="交易日 YYYYMMDD")],
    market: MarketOpt = None,
    fmt: cli_root.FormatOpt = None,
    output: cli_root.OutputOpt = None,
    host: cli_root.HostOpt = None,
    port: cli_root.PortOpt = None,
    config: cli_root.ConfigOpt = None,
) -> None:
    """历史单日分时（minutes 的明确命名别名）"""
    run(
        lambda c: c.history_minute(symbol=symbol, date=date, market=market),
        fmt=fmt, path=output, host=host, port=port, config=config,
    )


def index_bars(
    symbol: SymbolArg,
    freq: FreqOpt = "day",
    count: CountOpt = 100,
    market: MarketOpt = None,
    fmt: cli_root.FormatOpt = None,
    output: cli_root.OutputOpt = None,
    host: cli_root.HostOpt = None,
    port: cli_root.PortOpt = None,
    config: cli_root.ConfigOpt = None,
) -> None:
    """指数 K 线（880xxx 通达信指数、沪深指数）"""
    run(
        lambda c: c.index_bars(symbol=symbol, frequency=freq, count=count, market=market),
        fmt=fmt, path=output, host=host, port=port, config=config,
    )


def auction(
    symbol: SymbolArg,
    fmt: cli_root.FormatOpt = None,
    output: cli_root.OutputOpt = None,
    host: cli_root.HostOpt = None,
    port: cli_root.PortOpt = None,
    config: cli_root.ConfigOpt = None,
) -> None:
    """当日集合竞价序列"""
    run(
        lambda c: c.call_auction(symbol),
        fmt=fmt, path=output, host=host, port=port, config=config,
        need_protocol=True,
    )
