"""标准行情节点排名的用户目录缓存。"""

from __future__ import annotations

import hashlib
import json
import logging
import math
from pathlib import Path
from tempfile import NamedTemporaryFile
from time import time

logger = logging.getLogger("tdx_standard")

NODE_CACHE_TTL = 24 * 60 * 60


class NodeRankingCache:
    """按候选节点及超时配置隔离缓存，原子替换文件以支持多个 CLI 进程。"""

    def __init__(
        self,
        candidates: tuple[tuple[str, int], ...],
        connect_timeout: float,
        request_timeout: float,
    ) -> None:
        self.candidates = candidates
        identity = json.dumps([candidates, connect_timeout, request_timeout])
        digest = hashlib.sha256(identity.encode()).hexdigest()
        self.path = Path.home() / ".tdx-cli" / "nodes" / f"standard-{digest}.json"

    def load(self) -> tuple[tuple[str, int], ...] | None:
        """只接受未过期、属于当前候选集合的排名；损坏时重新测速。"""
        try:
            payload = json.loads(self.path.read_text(encoding="utf-8"))
            if not isinstance(payload, dict) or payload.get("version") != 1:
                return None
            updated_at = payload.get("updated_at")
            if type(updated_at) not in (int, float) or not math.isfinite(updated_at):
                return None
            if not 0 <= time() - updated_at < NODE_CACHE_TTL:
                return None
            rows = payload.get("servers")
            if not isinstance(rows, list) or not 1 <= len(rows) <= 3:
                return None
            servers = []
            for row in rows:
                if not isinstance(row, list) or len(row) != 2:
                    return None
                host, port = row
                if not isinstance(host, str) or type(port) is not int:
                    return None
                server = (host, port)
                if server not in self.candidates or server in servers:
                    return None
                servers.append(server)
            return tuple(servers)
        except FileNotFoundError:
            return None
        except (OSError, ValueError) as exc:
            logger.debug("读取节点缓存失败，将重新测速: %s", exc)
            return None

    def save(self, servers: tuple[tuple[str, int], ...]) -> None:
        """写入失败不影响已经建立的行情连接。"""
        temporary: Path | None = None
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            payload = {"version": 1, "updated_at": time(), "servers": servers}
            with NamedTemporaryFile(
                mode="w", encoding="utf-8", dir=self.path.parent, delete=False,
            ) as stream:
                temporary = Path(stream.name)
                json.dump(payload, stream)
            temporary.replace(self.path)
        except OSError as exc:
            logger.warning("保存节点缓存失败: %s", exc)
        finally:
            if temporary is not None:
                try:
                    temporary.unlink(missing_ok=True)
                except OSError as exc:
                    logger.debug("清理节点缓存临时文件失败: %s", exc)

    def invalidate(self) -> None:
        """失效节点不再作为下次连接的优选结果。"""
        try:
            self.path.unlink(missing_ok=True)
        except OSError as exc:
            logger.debug("清理节点缓存失败: %s", exc)
