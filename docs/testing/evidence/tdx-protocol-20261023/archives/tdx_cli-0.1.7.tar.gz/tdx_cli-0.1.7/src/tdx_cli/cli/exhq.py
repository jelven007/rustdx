"""扩展行情组命令（期货/港股/外盘）。"""

from __future__ import annotations

from typing import Annotated, Optional

import typer

import tdx_cli.cli as cli_root
from tdx_cli.cli.common import run as _run
from tdx_cli.tdx import ExFrequency

_EX_FREQ_VALUES = {
    "1m": ExFrequency.MINUTE_1,
    "5m": ExFrequency.MINUTE_5,
    "15m": ExFrequency.MINUTE_15,
    "30m": ExFrequency.MINUTE_30,
    "1h": ExFrequency.HOUR_1,
    "day": ExFrequency.DAY,
    "week": ExFrequency.WEEK,
    "month": ExFrequency.MONTH,
    "quarter": ExFrequency.QUARTER,
    "year": ExFrequency.YEAR,
}


def _ex_frequency_callback(value: str) -> int:
    if value not in _EX_FREQ_VALUES:
        raise typer.BadParameter(f"无效频率 {value}，可选: {'/'.join(_EX_FREQ_VALUES)}")
    return _EX_FREQ_VALUES[value]


def _date_int(label: str, value: Optional[str]) -> Optional[int]:
    """YYYYMMDD 字符串转 int；非法值报用法错误。"""
    if value is None:
        return None
    if not (value.isdigit() and len(value) == 8):
        raise typer.BadParameter(f"{label} 应为 YYYYMMDD: {value}")
    return int(value)


MarketArg = Annotated[int, typer.Argument(help="扩展市场代码，如 31=港股")]
CodeArg = Annotated[str, typer.Argument(help="扩展品种代码")]


def ex_markets(fmt: cli_root.FormatOpt = None, output: cli_root.OutputOpt = None, host: cli_root.HostOpt = None, port: cli_root.PortOpt = None, config: cli_root.ConfigOpt = None) -> None:
    """扩展行情市场代码表"""
    _run(lambda c: c.ex_markets(), fmt=fmt, path=output, host=host, port=port, config=config, need_extended=True)


def ex_count(fmt: cli_root.FormatOpt = None, output: cli_root.OutputOpt = None, host: cli_root.HostOpt = None, port: cli_root.PortOpt = None, config: cli_root.ConfigOpt = None) -> None:
    """扩展行情合约总数"""
    _run(lambda c: c.ex_count(), fmt=fmt, path=output, host=host, port=port, config=config, need_extended=True)


def ex_instruments(
    start: Annotated[int, typer.Option("--start", help="起始偏移")] = 0,
    count: Annotated[int, typer.Option("--count", help="条数")] = 100,
    fmt: cli_root.FormatOpt = None,
    output: cli_root.OutputOpt = None,
    host: cli_root.HostOpt = None,
    port: cli_root.PortOpt = None,
    config: cli_root.ConfigOpt = None,
) -> None:
    """扩展行情合约列表（分页）"""
    _run(lambda c: c.ex_instruments(start=start, count=count), fmt=fmt, path=output, host=host, port=port, config=config, need_extended=True)


def ex_quote(
    market: MarketArg,
    code: CodeArg,
    fmt: cli_root.FormatOpt = None,
    output: cli_root.OutputOpt = None,
    host: cli_root.HostOpt = None,
    port: cli_root.PortOpt = None,
    config: cli_root.ConfigOpt = None,
) -> None:
    """扩展品种五档行情"""
    _run(lambda c: c.ex_quote(market, code), fmt=fmt, path=output, host=host, port=port, config=config, need_extended=True)


def ex_quote_list(
    market: MarketArg,
    category: Annotated[int, typer.Option(help="类别: 2=港股 3=期货")] = 2,
    start: Annotated[int, typer.Option("--start")] = 0,
    count: Annotated[int, typer.Option("--count")] = 100,
    fmt: cli_root.FormatOpt = None,
    output: cli_root.OutputOpt = None,
    host: cli_root.HostOpt = None,
    port: cli_root.PortOpt = None,
    config: cli_root.ConfigOpt = None,
) -> None:
    """扩展行情列表"""
    _run(lambda c: c.ex_quote_list(market, category, start=start, count=count), fmt=fmt, path=output, host=host, port=port, config=config, need_extended=True)


def ex_bars(
    market: MarketArg,
    code: CodeArg,
    freq: Annotated[str, typer.Option("--freq", callback=_ex_frequency_callback, help="K线频率")] = "day",
    start: Annotated[int, typer.Option("--start")] = 0,
    count: Annotated[int, typer.Option("--count")] = 100,
    fmt: cli_root.FormatOpt = None,
    output: cli_root.OutputOpt = None,
    host: cli_root.HostOpt = None,
    port: cli_root.PortOpt = None,
    config: cli_root.ConfigOpt = None,
) -> None:
    """扩展品种 K 线"""
    _run(lambda c: c.ex_bars(freq, market, code, start=start, count=count), fmt=fmt, path=output, host=host, port=port, config=config, need_extended=True)


def ex_bars_range(
    market: MarketArg,
    code: CodeArg,
    start_date: Annotated[str, typer.Option("--start-date", help="YYYYMMDD")],
    end_date: Annotated[str, typer.Option("--end-date", help="YYYYMMDD")],
    fmt: cli_root.FormatOpt = None,
    output: cli_root.OutputOpt = None,
    host: cli_root.HostOpt = None,
    port: cli_root.PortOpt = None,
    config: cli_root.ConfigOpt = None,
) -> None:
    """扩展品种历史 K 线（日期区间）"""
    for label, value in (("start-date", start_date), ("end-date", end_date)):
        if not (value.isdigit() and len(value) == 8):
            raise typer.BadParameter(f"{label} 应为 YYYYMMDD: {value}")
    _run(
        lambda c: c.ex_bars_range(market, code, int(start_date), int(end_date)),
        fmt=fmt, path=output, host=host, port=port, config=config, need_extended=True,
    )


def ex_minute(
    market: MarketArg,
    code: CodeArg,
    date: Annotated[Optional[str], typer.Option("--date", help="YYYYMMDD（缺省实时）")] = None,
    fmt: cli_root.FormatOpt = None,
    output: cli_root.OutputOpt = None,
    host: cli_root.HostOpt = None,
    port: cli_root.PortOpt = None,
    config: cli_root.ConfigOpt = None,
) -> None:
    """扩展品种分时"""
    date_int = _date_int("--date", date)
    _run(lambda c: c.ex_minute(market, code, date=date_int), fmt=fmt, path=output, host=host, port=port, config=config, need_extended=True)


def ex_trades(
    market: MarketArg,
    code: CodeArg,
    start: Annotated[int, typer.Option("--start")] = 0,
    count: Annotated[int, typer.Option("--count")] = 100,
    date: Annotated[Optional[str], typer.Option("--date", help="YYYYMMDD（缺省实时）")] = None,
    fmt: cli_root.FormatOpt = None,
    output: cli_root.OutputOpt = None,
    host: cli_root.HostOpt = None,
    port: cli_root.PortOpt = None,
    config: cli_root.ConfigOpt = None,
) -> None:
    """扩展品种逐笔成交"""
    date_int = _date_int("--date", date)
    _run(lambda c: c.ex_trades(market, code, start=start, count=count, date=date_int), fmt=fmt, path=output, host=host, port=port, config=config, need_extended=True)
