"""通达信沪深标准行情原生协议实现。

帧、消息类型和字段布局以仓库内 ``tdx-master/protocol`` 为真相源。模块只依赖
Python 标准库，返回结构保持迁移前的字典契约，便于业务无感升级。
"""

from __future__ import annotations

import math
import socket
import struct
import zlib
from threading import Lock
from typing import Any

_RESPONSE_PREFIX = bytes.fromhex("b1cb7400")

TYPE_CONNECT = 0x000D
TYPE_LOGIN = 0x0FDB
TYPE_COUNT = 0x044E
TYPE_LIST = 0x0450
TYPE_QUOTES = 0x053E
TYPE_BARS = 0x052D
TYPE_MINUTE = 0x051D
TYPE_HISTORY_MINUTE = 0x0FB4
TYPE_TRADE = 0x0FC5
TYPE_HISTORY_TRADE = 0x0FB5
TYPE_XDXR = 0x000F
TYPE_FINANCE = 0x0010
TYPE_COMPANY_CATEGORY = 0x02CF
TYPE_COMPANY_CONTENT = 0x02D0

_LOGIN_DATA = bytes.fromhex(
    "d5d0c9ccd6a4a8af0000008fc22540130000d500c9ccbd f0d7ea00000002"
)
_XDXR_NAMES = {
    1: "除权除息", 2: "送配股上市", 3: "非流通股上市", 4: "未知股本变动",
    5: "股本变化", 6: "增发新股", 7: "股份回购", 8: "增发新股上市",
    9: "转配股上市", 10: "可转债上市", 11: "扩缩股", 12: "非流通股缩股",
    13: "送认购权证", 14: "送认沽权证",
}


class NativeTdxHqApi:
    """与 ``TdxHq_API`` 必要方法兼容的同步原生客户端。"""

    def __init__(self, **_options: Any) -> None:
        self.client: socket.socket | None = None
        self._message_id = 0
        self._lock = Lock()

    def connect(self, host: str, port: int, *, time_out: float) -> NativeTdxHqApi:
        self.close()
        self.client = socket.create_connection((host, port), timeout=time_out)
        self.client.settimeout(time_out)
        try:
            self._request(TYPE_CONNECT, b"\x01")
            self._request(TYPE_CONNECT, b"\x02")
            self._request(TYPE_LOGIN, _LOGIN_DATA)
        except Exception:
            self.close()
            raise
        return self

    def close(self) -> None:
        if self.client is not None:
            try:
                self.client.close()
            finally:
                self.client = None

    def get_security_count(self, market: int = 1) -> int:
        data = self._request(TYPE_COUNT, struct.pack("<H", market) + bytes.fromhex("75c73301"))
        _require(data, 2, "证券数量")
        return struct.unpack_from("<H", data)[0]

    def get_security_list(self, market: int, start: int) -> list[dict[str, Any]]:
        data = self._request(TYPE_LIST, struct.pack("<HH", market, start))
        _require(data, 2, "证券列表")
        count = struct.unpack_from("<H", data)[0]
        rows: list[dict[str, Any]] = []
        position = 2
        for _ in range(count):
            _require(data[position:], 29, "证券列表记录")
            code, volunit, name, _reserved1, decimal, raw_close, _reserved2 = struct.unpack_from(
                "<6sH8s4sBI4s", data, position
            )
            rows.append({
                "code": _ascii(code), "volunit": volunit, "decimal_point": decimal,
                "name": _gbk(name), "pre_close": _decode_volume(raw_close),
            })
            position += 29
        return rows

    def get_security_quotes(self, symbols: list[tuple[int, str]]) -> list[dict[str, Any]]:
        payload = bytearray(b"\x05\x00\x00\x00\x00\x00\x00\x00")
        payload.extend(struct.pack("<H", len(symbols)))
        for market, code in symbols:
            payload.extend(struct.pack("<B6s", market, _code(code)))
        return _parse_quotes(self._request(TYPE_QUOTES, bytes(payload)))

    def get_security_bars(
        self, category: int, market: int, code: str, start: int, count: int
    ) -> list[dict[str, Any]]:
        return self._get_bars(category, market, code, start, count, index=False)

    def get_index_bars(
        self, category: int, market: int, code: str, start: int, count: int
    ) -> list[dict[str, Any]]:
        return self._get_bars(category, market, code, start, count, index=True)

    def _get_bars(
        self, category: int, market: int, code: str, start: int, count: int, *, index: bool
    ) -> list[dict[str, Any]]:
        payload = (
            struct.pack("<H6sHHHH", market, _code(code), category, 1, start, count)
            + bytes(10)
        )
        return _parse_bars(self._request(TYPE_BARS, payload), category, index=index)

    def get_minute_time_data(self, market: int, code: str) -> list[dict[str, Any]]:
        payload = struct.pack("<H6sI", market, _code(code), 0)
        return _parse_minutes(self._request(TYPE_MINUTE, payload), market, code, history=False)

    def get_history_minute_time_data(
        self, market: int, code: str, date: int
    ) -> list[dict[str, Any]]:
        payload = struct.pack("<IB6s", date, market, _code(code))
        return _parse_minutes(
            self._request(TYPE_HISTORY_MINUTE, payload), market, code, history=True
        )

    def get_transaction_data(
        self, market: int, code: str, start: int, count: int
    ) -> list[dict[str, Any]]:
        payload = struct.pack("<H6sHH", market, _code(code), start, count)
        return _parse_trades(self._request(TYPE_TRADE, payload), history=False)

    def get_history_transaction_data(
        self, market: int, code: str, start: int, count: int, date: int
    ) -> list[dict[str, Any]]:
        payload = struct.pack("<IH6sHH", date, market, _code(code), start, count)
        return _parse_trades(self._request(TYPE_HISTORY_TRADE, payload), history=True)

    def get_xdxr_info(self, market: int, code: str) -> list[dict[str, Any]]:
        payload = b"\x01\x00" + struct.pack("<B6s", market, _code(code))
        return _parse_xdxr(self._request(TYPE_XDXR, payload))

    def get_finance_info(self, market: int, code: str) -> dict[str, Any]:
        payload = b"\x01\x00" + struct.pack("<B6s", market, _code(code))
        return _parse_finance(self._request(TYPE_FINANCE, payload))

    def get_company_info_category(self, market: int, code: str) -> list[dict[str, Any]]:
        payload = struct.pack("<H6sI", market, _code(code), 0)
        return _parse_company_categories(self._request(TYPE_COMPANY_CATEGORY, payload))

    def get_company_info_content(
        self, market: int, code: str, filename: str, start: int, length: int
    ) -> str:
        payload = bytearray(102)
        struct.pack_into("<H6s", payload, 0, market, _code(code))
        payload[10:90] = filename.encode("ascii")[:80].ljust(80, b"\0")
        struct.pack_into("<II", payload, 90, start, length)
        data = self._request(TYPE_COMPANY_CONTENT, bytes(payload))
        if len(data) < 12:
            return ""
        size = struct.unpack_from("<H", data, 10)[0]
        return data[12 : 12 + size].decode("gbk", errors="replace")

    def _request(self, message_type: int, data: bytes) -> bytes:
        if self.client is None:
            raise ConnectionError("通达信标准行情客户端尚未连接")
        with self._lock:
            self._message_id += 1
            message_id = self._message_id
            self.client.sendall(_frame(message_id, message_type, data))
            while True:
                response_id, response_type, response_data = self._read_response()
                if response_id != message_id:
                    continue
                if response_type != message_type:
                    raise ValueError(
                        f"通达信响应类型不匹配: {response_type:#x}/{message_type:#x}"
                    )
                return response_data

    def _read_response(self) -> tuple[int, int, bytes]:
        assert self.client is not None
        window = bytearray()
        while bytes(window) != _RESPONSE_PREFIX:
            window.extend(_recv_exact(self.client, 1))
            if len(window) > 4:
                del window[0]
        header = _recv_exact(self.client, 12)
        message_id = struct.unpack_from("<I", header, 1)[0]
        message_type, compressed_size, raw_size = struct.unpack_from("<HHH", header, 6)
        payload = _recv_exact(self.client, compressed_size)
        data = zlib.decompress(payload) if compressed_size != raw_size else payload
        if len(data) != raw_size:
            raise ValueError(f"通达信响应长度不匹配: {len(data)}/{raw_size}")
        return message_id, message_type, data


def _parse_quotes(data: bytes) -> list[dict[str, Any]]:
    _require(data, 4, "五档行情")
    reader = _Reader(data, 2)
    count = reader.u16()
    rows: list[dict[str, Any]] = []
    for _ in range(count):
        market, code, active1 = reader.u8(), _ascii(reader.read(6)), reader.u16()
        coefficient = _coefficient(market, code)
        base = reader.varint()
        last_close = base + reader.varint()
        open_price = base + reader.varint()
        high = base + reader.varint()
        low = base + reader.varint()
        server_time, reserved1 = reader.varint(), reader.varint()
        volume, current_volume = reader.varint(), reader.varint()
        amount = _decode_volume(reader.u32())
        sell_volume, buy_volume = reader.varint(), reader.varint()
        reserved2, reserved3 = reader.varint(), reader.varint()
        bids: list[float] = []
        asks: list[float] = []
        bid_volumes: list[int] = []
        ask_volumes: list[int] = []
        for _level in range(5):
            bids.append((base + reader.varint()) * coefficient)
            asks.append((base + reader.varint()) * coefficient)
            bid_volumes.append(reader.varint())
            ask_volumes.append(reader.varint())
        reserved4 = reader.u16()
        reserved = [reader.varint() for _ in range(4)]
        rate, active2 = reader.i16() / 100.0, reader.u16()
        row: dict[str, Any] = {
            "market": market, "code": code, "active1": active1,
            "price": base * coefficient, "last_close": last_close * coefficient,
            "open": open_price * coefficient, "high": high * coefficient,
            "low": low * coefficient, "servertime": _format_server_time(server_time),
            "reversed_bytes0": server_time, "reversed_bytes1": reserved1,
            "vol": volume, "cur_vol": current_volume, "amount": amount,
            "s_vol": sell_volume, "b_vol": buy_volume,
            "reversed_bytes2": reserved2, "reversed_bytes3": reserved3,
            "reversed_bytes4": reserved4, "reversed_bytes5": reserved[0],
            "reversed_bytes6": reserved[1], "reversed_bytes7": reserved[2],
            "reversed_bytes8": reserved[3], "reversed_bytes9": rate,
            "active2": active2,
        }
        for index in range(5):
            level = index + 1
            row[f"bid{level}"] = bids[index]
            row[f"ask{level}"] = asks[index]
            row[f"bid_vol{level}"] = bid_volumes[index]
            row[f"ask_vol{level}"] = ask_volumes[index]
        rows.append(row)
    return rows


def _parse_bars(data: bytes, category: int, *, index: bool) -> list[dict[str, Any]]:
    _require(data, 2, "K线")
    reader = _Reader(data, 2)
    count = struct.unpack_from("<H", data)[0]
    previous_close = 0
    result: list[dict[str, Any]] = []
    for _ in range(count):
        year, month, day, hour, minute = _decode_datetime(reader.read(4), category)
        open_diff, close_diff = reader.varint(), reader.varint()
        high_diff, low_diff = reader.varint(), reader.varint()
        open_raw = previous_close + open_diff
        close_raw = open_raw + close_diff
        row = {
            "open": open_raw / 1000.0, "close": close_raw / 1000.0,
            "high": (open_raw + high_diff) / 1000.0,
            "low": (open_raw + low_diff) / 1000.0,
            "vol": _decode_volume(reader.u32()), "amount": _decode_volume(reader.u32()),
            "year": year, "month": month, "day": day, "hour": hour, "minute": minute,
            "datetime": f"{year:04d}-{month:02d}-{day:02d} {hour:02d}:{minute:02d}",
        }
        previous_close = close_raw
        if index:
            row["up_count"], row["down_count"] = reader.u16(), reader.u16()
        result.append(row)
    return result


def _parse_minutes(
    data: bytes, market: int, code: str, *, history: bool
) -> list[dict[str, Any]]:
    minimum = 6 if history else 4
    _require(data, minimum, "分时")
    count = struct.unpack_from("<H", data)[0]
    reader = _Reader(data, 6 if history else 4)
    coefficient = _coefficient(market, code)
    last_price = 0
    rows: list[dict[str, Any]] = []
    for _ in range(count):
        last_price += reader.varint()
        reader.varint()
        rows.append({"price": last_price * coefficient, "vol": reader.varint()})
    return rows


def _parse_trades(data: bytes, *, history: bool) -> list[dict[str, Any]]:
    minimum = 6 if history else 2
    _require(data, minimum, "逐笔成交")
    count = struct.unpack_from("<H", data)[0]
    reader = _Reader(data, 6 if history else 2)
    last_price = 0
    rows: list[dict[str, Any]] = []
    for _ in range(count):
        minutes = reader.u16()
        last_price += reader.varint()
        volume = reader.varint()
        if history:
            orders = None
        else:
            orders = reader.varint()
        status = reader.varint()
        reader.varint()
        row = {
            "time": f"{minutes // 60:02d}:{minutes % 60:02d}",
            "price": last_price / 100.0, "vol": volume, "buyorsell": status,
        }
        if orders is not None:
            row["num"] = orders
        rows.append(row)
    return rows


def _parse_xdxr(data: bytes) -> list[dict[str, Any]]:
    if len(data) < 11:
        return []
    count = struct.unpack_from("<H", data, 9)[0]
    reader = _Reader(data, 11)
    rows: list[dict[str, Any]] = []
    for _ in range(count):
        reader.skip(7)
        reader.skip(1)
        raw_date = reader.u32()
        year, month, day, _, _ = _decode_datetime(struct.pack("<I", raw_date), 9)
        category = reader.u8()
        values = reader.read(16)
        row: dict[str, Any] = {
            "year": year, "month": month, "day": day, "category": category,
            "name": _XDXR_NAMES.get(category, str(category)),
            "fenhong": None, "peigujia": None, "songzhuangu": None, "peigu": None,
            "suogu": None, "panqianliutong": None, "panhouliutong": None,
            "qianzongguben": None, "houzongguben": None, "fenshu": None,
            "xingquanjia": None,
        }
        if category == 1:
            row["fenhong"], row["peigujia"], row["songzhuangu"], row["peigu"] = (
                float(value) for value in struct.unpack("<ffff", values)
            )
        elif category in {11, 12}:
            row["suogu"] = float(struct.unpack_from("<f", values, 8)[0])
        elif category in {13, 14}:
            row["xingquanjia"] = float(struct.unpack_from("<f", values)[0])
            row["fenshu"] = float(struct.unpack_from("<f", values, 8)[0])
        else:
            before_float, before_total, after_float, after_total = struct.unpack("<IIII", values)
            row.update({
                "panqianliutong": _decode_volume(before_float),
                "qianzongguben": _decode_volume(before_total),
                "panhouliutong": _decode_volume(after_float),
                "houzongguben": _decode_volume(after_total),
            })
        rows.append(row)
    return rows


def _parse_finance(data: bytes) -> dict[str, Any]:
    _require(data, 145, "财务信息")
    market = data[2]
    code = _ascii(data[3:9])
    values = struct.unpack_from("<fHHII" + "f" * 30, data, 9)
    names = (
        "zongguben", "guojiagu", "faqirenfarengu", "farengu", "bgu", "hgu",
        "zhigonggu", "zongzichan", "liudongzichan", "gudingzichan", "wuxingzichan",
        "gudongrenshu", "liudongfuzhai", "changqifuzhai", "zibengongjijin",
        "jingzichan", "zhuyingshouru", "zhuyinglirun", "yingshouzhangkuan",
        "yingyelirun", "touzishouyu", "jingyingxianjinliu", "zongxianjinliu",
        "cunhuo", "lirunzonghe", "shuihoulirun", "jinglirun", "weifenpeilirun",
        "meigujingzichan", "baoliu2",
    )
    result: dict[str, Any] = {
        "market": market, "code": code, "liutongguben": values[0] * 10000,
        "province": values[1], "industry": values[2], "updated_date": values[3],
        "ipo_date": values[4],
    }
    for index, name in enumerate(names):
        value = float(values[index + 5])
        result[name] = value if name in {"gudongrenshu", "meigujingzichan", "baoliu2"} else value * 10000
    return result


def _parse_company_categories(data: bytes) -> list[dict[str, Any]]:
    if len(data) < 2:
        return []
    count = struct.unpack_from("<H", data)[0]
    rows: list[dict[str, Any]] = []
    position = 2
    for _ in range(count):
        if position + 152 > len(data):
            break
        rows.append({
            "name": _gbk(data[position : position + 64]),
            "filename": _ascii(data[position + 64 : position + 144]),
            "start": struct.unpack_from("<I", data, position + 144)[0],
            "length": struct.unpack_from("<I", data, position + 148)[0],
        })
        position += 152
    return rows


class _Reader:
    def __init__(self, data: bytes, position: int = 0) -> None:
        self.data = data
        self.position = position

    def read(self, size: int) -> bytes:
        if self.position + size > len(self.data):
            raise ValueError(f"通达信响应记录截断: pos={self.position}, need={size}")
        value = self.data[self.position : self.position + size]
        self.position += size
        return value

    def skip(self, size: int) -> None:
        self.read(size)

    def u8(self) -> int:
        return self.read(1)[0]

    def u16(self) -> int:
        return struct.unpack("<H", self.read(2))[0]

    def i16(self) -> int:
        return struct.unpack("<h", self.read(2))[0]

    def u32(self) -> int:
        return struct.unpack("<I", self.read(4))[0]

    def varint(self) -> int:
        first = self.u8()
        value = first & 0x3F
        shift = 6
        current = first
        while current & 0x80:
            current = self.u8()
            value += (current & 0x7F) << shift
            shift += 7
        return -value if first & 0x40 else value


def _frame(message_id: int, message_type: int, data: bytes) -> bytes:
    length = len(data) + 2
    return b"\x0c" + struct.pack("<IBHHH", message_id, 1, length, length, message_type) + data


def _recv_exact(sock: socket.socket, size: int) -> bytes:
    result = bytearray()
    while len(result) < size:
        chunk = sock.recv(size - len(result))
        if not chunk:
            raise ConnectionError("通达信服务器提前关闭连接")
        result.extend(chunk)
    return bytes(result)


def _decode_volume(value: int | bytes) -> float:
    raw = struct.unpack("<I", value)[0] if isinstance(value, bytes) else value
    logpoint = raw >> 24
    hleax, lheax, lleax = (raw >> 16) & 0xFF, (raw >> 8) & 0xFF, raw & 0xFF
    ecx, edx, esi, eax = logpoint * 2 - 0x7F, logpoint * 2 - 0x86, logpoint * 2 - 0x8E, logpoint * 2 - 0x96
    high = math.pow(2.0, ecx)
    if hleax > 0x80:
        middle = math.pow(2.0, edx) * 128 + (hleax & 0x7F) * math.pow(2.0, edx + 1)
    else:
        middle = math.pow(2.0, edx) * hleax
    low = math.pow(2.0, esi) * lheax + math.pow(2.0, eax) * lleax
    if hleax & 0x80:
        low *= 2
    return high + middle + low


def _decode_datetime(data: bytes, category: int) -> tuple[int, int, int, int, int]:
    if category < 4 or category in {7, 8}:
        packed_day, minutes = struct.unpack("<HH", data)
        year = (packed_day >> 11) + 2004
        month, day = (packed_day % 2048) // 100, (packed_day % 2048) % 100
        return year, month, day, minutes // 60, minutes % 60
    packed_day = struct.unpack("<I", data)[0]
    return packed_day // 10000, packed_day % 10000 // 100, packed_day % 100, 15, 0


def _coefficient(market: int, code: str) -> float:
    prefix = code[:2]
    if market == 1:
        if prefix in {"50", "51", "52", "53", "56", "58"}:
            return 0.001
        if prefix in {"01", "10", "11", "12", "13", "14", "20"}:
            return 0.0001
        if prefix == "90":
            return 0.001
    elif market == 0:
        if prefix in {"15", "16"}:
            return 0.001
        if prefix in {"10", "11", "12", "13", "14"}:
            return 0.0001
    return 0.01


def _format_server_time(value: int) -> str:
    text = str(value)
    if value == 0 or len(text) < 6 or not text.isdecimal():
        return text
    prefix = text[:-6] or "0"
    middle = int(text[-6:-4])
    if middle < 60:
        return f"{prefix}:{text[-6:-4]}:{int(text[-4:]) * 60 / 10000.0:06.3f}"
    remainder = int(text[-6:])
    return f"{prefix}:{remainder * 60 // 1000000:02d}:{(remainder * 60 % 1000000) * 60 / 1000000.0:06.3f}"


def _code(value: str) -> bytes:
    encoded = value.encode("ascii")
    if len(encoded) != 6:
        raise ValueError(f"通达信证券代码必须为 6 位: {value}")
    return encoded


def _ascii(value: bytes) -> str:
    return value.split(b"\0", 1)[0].decode("ascii", errors="ignore")


def _gbk(value: bytes) -> str:
    return value.split(b"\0", 1)[0].decode("gbk", errors="replace").strip()


def _require(data: bytes, size: int, label: str) -> None:
    if len(data) < size:
        raise ValueError(f"{label}响应长度不足: {len(data)}/{size}")
