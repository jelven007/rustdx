"""配置加载（内置 → ~/.tdx-cli/config.toml → 命令行）与客户端工厂。"""

from __future__ import annotations

import logging
import tomllib
from dataclasses import dataclass
from pathlib import Path

from tdx_cli.tdx import TdxClient
from tdx_cli.tdx_blocks import TdxProtocolClient
from tdx_cli.tdx_exhq import ExHqClient
from tdx_cli.tdx_standard import TdxStandardClient

logger = logging.getLogger("tdx_cli.context")

CONFIG_DIR = ".tdx-cli"
CONFIG_FILE = "config.toml"


@dataclass
class Config:
    standard_servers: list[tuple[str, int]] | None = None
    blocks_servers: list[tuple[str, int]] | None = None
    extended_servers: list[tuple[str, int]] | None = None
    output_format: str = "table"

    def apply_host_override(self, host: str, port: int) -> None:
        """--host/--port 指定后仅使用该节点（放弃内置 failover 列表）。"""
        self.standard_servers = [(host, port)]


def parse_servers(values: list[str]) -> list[tuple[str, int]]:
    """把 ``["host:port", ...]`` 解析为元组列表。"""
    result = []
    for value in values:
        host, _, port_text = value.rpartition(":")
        if not host or not port_text.isdigit():
            raise ValueError(f"无效服务器地址: {value}（应为 host:port）")
        result.append((host, int(port_text)))
    return result


def load_config(config_path: Path | None = None) -> Config:
    """加载配置文件；不存在用内置默认，解析失败警告后回退默认。"""
    path = config_path or (Path.home() / CONFIG_DIR / CONFIG_FILE)
    cfg = Config()
    if not path.is_file():
        return cfg
    try:
        raw = tomllib.loads(path.read_text(encoding="utf-8"))
    except (tomllib.TOMLDecodeError, OSError) as exc:
        logger.warning("配置文件解析失败 %s: %s，使用内置默认", path, exc)
        return cfg

    for section, attr in (
        ("standard", "standard_servers"),
        ("blocks", "blocks_servers"),
        ("extended", "extended_servers"),
    ):
        raw_section = raw.get(section)
        values = raw_section.get("servers") if isinstance(raw_section, dict) else None
        if isinstance(values, list):
            try:
                setattr(cfg, attr, parse_servers([str(v) for v in values]))
            except ValueError as exc:
                logger.warning("配置 %s.servers 无效: %s", section, exc)
        elif values is not None:
            logger.warning("配置 %s.servers 应为地址列表，已忽略", section)

    raw_output = raw.get("output")
    output_format = raw_output.get("format") if isinstance(raw_output, dict) else None
    if output_format:
        cfg.output_format = str(output_format)
    return cfg


def make_client(
    cfg: Config,
    *,
    need_protocol: bool = False,
    need_extended: bool = False,
) -> TdxClient:
    """构造 TdxClient；预注入的客户端已全部显式连接（懒连接约束）。"""
    standard = TdxStandardClient(servers=cfg.standard_servers or None)
    standard.connect()

    protocol: TdxProtocolClient | None = None
    if need_protocol:
        protocol = TdxProtocolClient(servers=cfg.blocks_servers or None)
        protocol.connect()

    extended: ExHqClient | None = None
    if need_extended:
        extended = ExHqClient(servers=cfg.extended_servers or None)
        extended.connect()

    return TdxClient(
        standard_client=standard,
        protocol_client=protocol,
        extended_client=extended,
    )


def run_with_client(
    handler,
    cfg: Config,
    *,
    need_protocol: bool = False,
    need_extended: bool = False,
) -> None:
    """建连 → handler(client) → 关闭；连接失败以退出码 2 结束。"""
    import typer

    try:
        client = make_client(cfg, need_protocol=need_protocol, need_extended=need_extended)
    except ConnectionError as exc:
        typer.secho(f"连接失败: {exc}", err=True, fg=typer.colors.RED)
        raise typer.Exit(code=2)
    with client:
        handler(client)
