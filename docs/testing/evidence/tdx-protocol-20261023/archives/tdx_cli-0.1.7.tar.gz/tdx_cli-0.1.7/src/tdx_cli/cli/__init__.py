"""tdx 命令行入口：全局选项 + 子命令注册。"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Annotated, Optional

import typer

from tdx_cli.cli.context import Config, load_config
from tdx_cli.cli.output import Format

app = typer.Typer(
    help="通达信数据 CLI：K线/行情/分笔/F10/板块/文件/扩展行情",
    no_args_is_help=True,
)

HostOpt = Annotated[
    Optional[str],
    typer.Option("--host", help="标准行情服务器地址（指定后仅连该节点）"),
]
PortOpt = Annotated[
    Optional[int],
    typer.Option("--port", help="标准行情服务器端口（配合 --host）"),
]
FormatOpt = Annotated[
    Optional[Format],
    typer.Option("--format", help="输出格式：table/json/csv/parquet"),
]
OutputOpt = Annotated[
    Optional[Path],
    typer.Option("-o", "--output", help="输出文件路径（按后缀推断格式）"),
]
ConfigOpt = Annotated[
    Optional[Path],
    typer.Option("--config", help="配置文件路径（默认 ~/.tdx-cli/config.toml）"),
]


def build_config(
    config: Optional[Path], host: Optional[str], port: Optional[int]
) -> Config:
    """组装配置：内置 → 文件 → 命令行覆盖。"""
    cfg = load_config(config)
    if host:
        cfg.apply_host_override(host, port if port is not None else 7709)
    return cfg


def resolve_emit_format(fmt: Optional[Format], cfg: Config) -> Format:
    """--format 未显式给时用配置文件的 [output].format；非法值警告后回退 table。"""
    if fmt is not None:
        return fmt
    try:
        return Format(cfg.output_format)
    except ValueError:
        import logging

        logging.getLogger("tdx_cli.cli").warning(
            "配置 output.format=%r 无效，回退 table", cfg.output_format
        )
        return Format.TABLE


def is_pipe() -> bool:
    """stdout 非 TTY（管道）时 table 自动降级 json。"""
    return not sys.stdout.isatty()


from tdx_cli.cli import blocks, exhq, f10, files, kline, quote, trades  # noqa: E402

app.command()(kline.kline)
app.command()(kline.minute)
app.command()(kline.minutes)
app.command()(kline.minute_history)
app.command()(kline.index_bars)
app.command()(kline.auction)
app.command()(quote.quote)
app.command()(quote.securities)
app.command()(quote.stock_count)
app.command()(trades.trades)
app.command()(f10.f10)
app.command()(f10.f10_categories)
app.command()(f10.f10_content)
app.command()(f10.finance)
app.command()(f10.xdxr)
app.command()(f10.xdxr_all)
app.command()(blocks.blocks)
app.command()(blocks.block)
app.command()(blocks.special_blocks)
app.command()(blocks.industry_assignments)
app.command()(blocks.stock_stats)
app.command()(blocks.stock_stats2)
app.command()(blocks.ipo_subscriptions)
app.command()(blocks.index_definitions)
app.command()(blocks.block_aliases)
app.command()(files.report_file)
app.command()(files.zhb_files)
app.command()(exhq.ex_markets)
app.command()(exhq.ex_count)
app.command()(exhq.ex_instruments)
app.command()(exhq.ex_quote)
app.command()(exhq.ex_quote_list)
app.command()(exhq.ex_bars)
app.command()(exhq.ex_bars_range)
app.command()(exhq.ex_minute)
app.command()(exhq.ex_trades)
