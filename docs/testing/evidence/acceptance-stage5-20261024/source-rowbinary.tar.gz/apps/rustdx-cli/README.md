# rustdx CLI

包名 `jelven-rustdx-cli`，库名 `rustdx_cli`，二进制 `rustdx`。Rust 2024 / MSRV 1.89。处理通达信日线目录、官网 ZIP、指定 URL 或本地 ZIP，输出 CSV、质量清单，或导入 ClickHouse/MongoDB 并精确回读。

```sh
cargo install --path apps/rustdx-cli --locked
rustdx --no-tcp-startup day /path/to/lday -o /path/to/stocks.csv \
  --report /path/to/collection.json
rustdx day --help
```

以上构建命令从仓库根执行。所有全局参数放在子命令前；有效命令默认先初始化 TCP 当日池，离线文件操作显式加 `--no-tcp-startup`。

成功须同时满足退出码、清单、产物与适用的数据库精确验收；`acknowledged` 仍须继续回读。失败、确认丢失或不一致时保留 CSV，恢复前核实目标及较新数据。

CSV 量为手，factor 为累计收益指数，原始 OHLC 不被该因子缩放。配置由命令行和进程环境显式传入，CLI 不自动读取 runtime.env。

新增`tcp-day --directory <private-candidate>`供runner或受控调用者使用：
目录包含严格`tcp-request.json`、单位材料`facts/<sha256>`和空`raw`。
使用`--no-tcp-startup`跳过通用预热后，采集器仍对显式端点执行三轮协议探测。
仅支持最多32只沪深A股的已结束日期，逐证券同步、有界留证和独立回读。
该命令schema8 CSV量为股，报告明确来源合同与`business_coverage=unverified`；
旧`day` CSV单位保持手。最终业务覆盖、封存与修订由runner完成。
库接口为`tcp_day::{Source, Request, collect, replay_security}`。

仓库中的[导入状态与恢复约定](https://github.com/jelven007/rustdx/blob/main/docs/operations/IMPORTS.md)、[运行配置](https://github.com/jelven007/rustdx/blob/main/config/README.md)和[运维手册](https://github.com/jelven007/rustdx/blob/main/docs/runbooks/RUNBOOK.md)随源码维护。发布版本与当前源码须按提交区分；本包保留 LICENSE-MIT。
