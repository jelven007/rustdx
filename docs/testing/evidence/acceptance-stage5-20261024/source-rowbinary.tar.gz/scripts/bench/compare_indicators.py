#!/usr/bin/env python3
"""Compare like-for-like indicator observations; timing is not market acceptance."""
import argparse
import json
from pathlib import Path


def load(path):
    report = json.loads(path.read_text())
    if report["schema_version"] != 1 or report["statistic"] != "median":
        raise ValueError("unsupported benchmark schema")
    entries = {}
    for measurement in report["measurements"]:
        key = (measurement["name"], measurement["rows"], measurement["period"])
        if key in entries or measurement["median_ns"] <= 0:
            raise ValueError("duplicate benchmark key or nonpositive timing")
        entries[key] = measurement["median_ns"]
    if not entries:
        raise ValueError("empty benchmark")
    return report, entries


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline", required=True, type=Path)
    parser.add_argument("--current", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--max-ratio", default=1.5, type=float)
    args = parser.parse_args()
    if not 1.0 <= args.max_ratio <= 100:
        parser.error("max-ratio must be finite and in [1,100]")
    before, old = load(args.baseline)
    after, new = load(args.current)
    for field in ["os", "arch", "statistic", "samples_per_measurement", "synthetic"]:
        if before[field] != after[field]:
            raise ValueError(f"benchmark environment differs: {field}")
    if old.keys() != new.keys():
        raise ValueError("benchmark measurement sets differ")
    rows = [{"name": key[0], "rows": key[1], "period": key[2], "ratio": new[key] / old[key],
             "passed": new[key] / old[key] <= args.max_ratio} for key in sorted(old)]
    result = {"passed": all(row["passed"] for row in rows), "max_ratio": args.max_ratio,
              "scope": "same OS/arch/schema; user must match hardware/toolchain/load", "measurements": rows}
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    raise SystemExit(0 if result["passed"] else 1)


if __name__ == "__main__":
    main()
