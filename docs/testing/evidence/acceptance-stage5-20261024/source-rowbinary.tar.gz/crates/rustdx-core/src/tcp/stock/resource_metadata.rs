//! Checked 02c5 metadata, including the hash and uninterpreted response bytes.
use super::command_request::{CommandSource, bounded, input, invalid};
use crate::tcp::{Tcp, reader::Reader};
use serde::Serialize;
use std::{io, sync::Arc};

pub const BLOCK_META_COMMAND: u16 = 0x02c5;

#[derive(Debug, Clone, Serialize)]
pub struct BlockMetaRequest {
    filename: String,
}
impl BlockMetaRequest {
    pub fn new(filename: &str) -> io::Result<Self> {
        let filename = filename.trim();
        if filename.is_empty()
            || filename.len() > 40
            || !filename.is_ascii()
            || filename.as_bytes().contains(&0)
        {
            return Err(input("板块文件名须为1..40字节ASCII且不含NUL"));
        }
        Ok(Self {
            filename: filename.into(),
        })
    }
    pub fn filename(&self) -> &str {
        &self.filename
    }
    pub fn encode(&self, id: u32) -> io::Result<Vec<u8>> {
        let mut body = [0; 40];
        body[..self.filename.len()].copy_from_slice(self.filename.as_bytes());
        crate::tcp::frame::request(BLOCK_META_COMMAND, id, &body)
    }
    pub fn recv(&self, tcp: &mut Tcp) -> io::Result<BlockMetadata> {
        let bytes = tcp.exchange_checked(&self.encode(crate::tcp::frame::sequence())?)?;
        let mut result = decode_block_metadata(&bytes)?;
        result.source.attach(tcp)?;
        Ok(result)
    }
}

#[derive(Debug, Clone, Serialize)]
pub struct BlockMetadata {
    pub size: u32,
    pub md5: String,
    pub reserved_raw: u8,
    pub md5_raw: [u8; 32],
    pub terminator_raw: u8,
    pub trailing_payload: Vec<u8>,
    pub source: CommandSource,
    #[serde(skip)]
    pub raw_payload: Arc<[u8]>,
}

pub fn decode_block_metadata(bytes: &[u8]) -> io::Result<BlockMetadata> {
    bounded(bytes)?;
    let mut reader = Reader::new(bytes);
    let size = reader.u32()?;
    let reserved_raw = reader.u8()?;
    let md5_raw: [u8; 32] = reader.take(32)?.try_into().unwrap();
    if !md5_raw.is_ascii() {
        return Err(invalid("02c5 MD5字段不是ASCII"));
    }
    let end = md5_raw.iter().position(|b| *b == 0).unwrap_or(32);
    let md5 = std::str::from_utf8(&md5_raw[..end])
        .map_err(|e| io::Error::new(io::ErrorKind::InvalidData, e))?
        .trim()
        .to_owned();
    let terminator_raw = reader.u8()?;
    Ok(BlockMetadata {
        size,
        md5,
        reserved_raw,
        md5_raw,
        terminator_raw,
        trailing_payload: reader.take(reader.remaining())?.to_vec(),
        source: CommandSource::offline(BLOCK_META_COMMAND),
        raw_payload: bytes.into(),
    })
}
